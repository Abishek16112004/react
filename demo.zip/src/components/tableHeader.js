const TableHeader = () => {

    return (
        <>
            <div className="container mt-5">
                <h2 className="text-center">Records Details</h2>
                <div className="row">
                    <div className="col-sm-6">
                    </div>
                    <div className="col-sm-2">

                    </div>
                    <div className="col-sm-4">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">
                            Add
                        </button>
                    </div>
                </div>
            </div>
        </>
    )
}

export default TableHeader;