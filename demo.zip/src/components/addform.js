import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import axios from 'axios';
import { addUser, editUser } from '../store/slices/usersSlice';

const AddForm = ({ user, onSave }) => {
  const dispatch = useDispatch();
  const [name, setName] = useState(user ? user.name : '');
  const [email, setEmail] = useState(user ? user.email : '');
  const [phone, setPhone] = useState(user ? user.phone : '');
  const [errors, setErrors] = useState({});

  const handleAddUser = async (event) => {
    event.preventDefault(); // Prevent default form submission behavior

    const userData = {
      name: name,
      email: email,
      phone: phone,
    };

    try {
      const response = await axios.post('http://localhost:3001/api/users', userData);

      if (response.status === 200) {
        // User added successfully
        const newUser = response.data;
        dispatch(addUser(newUser));

        // Reset the form fields
        setName('');
        setEmail('');
        setPhone('');

        // Call the onSave prop if provided
        if (onSave) {
          onSave();
        }
      }
    } catch (error) {
        if (error.response && error.response.data && error.response.data.errors) {
            // Server-side validation failed
            const errorData = error.response.data.errors;
            console.log('Validation errors:', errorData); // Check the error messages in the console
            setErrors(errorData);
        } else {
            // Handle any network or server errors
            console.log('Failed to add user', error);
        }
    }
  };

  return (
    <>
      <form onSubmit={handleAddUser}>
        <div className="mb-3">
        {errors.name && <div className="invalid-feedback">{errors.name}</div>}

          <label htmlFor="name" className="form-label">
            Name:
          </label>
          <input
            type="text"
            className={`form-control ${errors.name ? 'is-invalid' : ''}`}
            id="name"
            placeholder="Enter Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div className="mb-3 mt-3">
          <label htmlFor="email" className="form-label">
            Email:
          </label>
          <input
            type="email"
            className={`form-control ${errors.email ? 'is-invalid' : ''}`}
            id="email"
            placeholder="Enter email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          {errors.email && <div className="invalid-feedback">{errors.email}</div>}
        </div>
        <div className="mb-3">
          <label htmlFor="phone" className="form-label">
            Phone:
          </label>
          <input
            type="text"
            className={`form-control ${errors.phone ? 'is-invalid' : ''}`}
            id="phone"
            placeholder="Enter Phone Number"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
          {errors.phone && <div className="invalid-feedback text-danger">{errors.phone}</div>}
        </div>
        <button type="submit" className="btn btn-primary">
          {user ? 'Save' : 'Submit'}
        </button>
      </form>
    </>
  );
};

export default AddForm;
