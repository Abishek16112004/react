import { useSelector, useDispatch } from "react-redux";
import Swal from 'sweetalert2';
import { editUser, deleteUser } from "../store/slices/usersSlice";
import { useState } from "react";
import AddForm from "./addform";

const Table = () => {
    const users = useSelector((state) => state.users);
    const dispatch = useDispatch();
    const [editUserModalOpen, setEditUserModalOpen] = useState(false);
    const [selectedUser, setSelectedUser] = useState(null);

    const handleEditUser = (user) => {
        setSelectedUser(user);
        setEditUserModalOpen(true);
    };

    const handleSaveUser = () => {
        dispatch(editUser(selectedUser));
        setEditUserModalOpen(false);
    };

    const handleDeleteUser = (user) => {
        Swal.fire({
            title: 'Are you sure?',
            text: "You want to delete this user!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                dispatch(deleteUser(user.id));
                Swal.fire(
                    'Deleted!',
                    'Record has been deleted successfully.',
                    'success'
                );
            }
        });
    };

    return (
        <>
            <div className="container mt-3">
                <table className="table table-bordered text-center align-item-center m-auto" style={{ width: '60%' }}>
                    <thead className="table-dark">
                        <tr>
                            <th>Sr.No</th>
                            <th>Firstname</th>
                            <th>Email</th>
                            <th>Phone.No</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map((user, index) => (
                            <tr key={user.id}>
                                <td>{index + 1}</td>
                                <td>{user.name}</td>
                                <td>{user.email}</td>
                                <td>{user.phone}</td>
                                <td>
                                    <i className="fa fa-pencil-square text-primary" onClick={() => handleEditUser(user)}></i>  <i className="fa fa-trash-can text-danger" onClick={() => handleDeleteUser(user)}></i>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Edit User Modal */}
            {editUserModalOpen && selectedUser && (
                <div className="modal" id="myModal" style={{ display: "block" }}>
                    <div className="modal-dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h4 className="modal-title">Edit User</h4>
                                <button type="button" className="btn-close" onClick={() => setEditUserModalOpen(false)}></button>
                            </div>
                            <div className="modal-body">
                                <AddForm user={selectedUser} />
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-danger" onClick={handleSaveUser}>Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
};

export default Table;
