import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import User from "../../server/models/userModels";

// Async thunk for adding a user
export const addUserAsync = createAsyncThunk(
  "users/addUser",
  async (userData) => {
    const { name, email, phone } = userData;
    const newUser = new User({ name, email, phone });
    try {
      const savedUser = await newUser.save();
      return savedUser;
    } catch (error) {
      throw new Error("Failed to save user");
    }
  }
);

const usersSlice = createSlice({
  name: "users",
  initialState: JSON.parse(localStorage.getItem("users")) || [
    {
      id: 1,
      name: "Ajay",
      email: "ajay@gmail.com",
      phone: 12134567890,
    },
    {
      id: 2,
      name: "Abhishek",
      email: "abhishek@gmail.com",
      phone: 12134567890,
    },
  ],
  reducers: {
    // other reducer functions...

    // Handle the fulfilled action from addUserAsync
    addUser: (state, action) => {
      state.push(action.payload);
      localStorage.setItem("users", JSON.stringify(state));
    },
  },
  extraReducers: (builder) => {
    // Handle the pending and rejected actions from addUserAsync
    builder.addCase(addUserAsync.fulfilled, (state, action) => {
      state.push(action.payload);
      localStorage.setItem("users", JSON.stringify(state));
    });
  },
    // Delete user Function
    deleteUser: (state, action) => {
        const userId = action.payload;
        const userIndex = state.findIndex((user) => user.id === userId);
        if (userIndex !== -1) {
            state.splice(userIndex, 1);
            localStorage.setItem("users", JSON.stringify(state));
        }
    },
});


export const { addUser, editUser, deleteUser } = usersSlice.actions;
export default usersSlice.reducer;
