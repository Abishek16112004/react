import Navbar from './components/navbar';
import TableHeader from './components/tableHeader';
import Table from './components/table';
import ModalForm from './components/modalForm';


function App() {
  return (
    <>
      <Navbar />
      <TableHeader />
      <ModalForm />
      <Table />

    </>
  );
}

export default App;
