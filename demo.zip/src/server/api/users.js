const { MongoClient } = require('mongodb');

// MongoDB Atlas connection string
const uri = 'mongodb+srv://kabishek:KnyRKUFrM7hr9BXQ@cluster0.3vnej3o.mongodb.net/db?retryWrites=true&w=majority';

// Create a new MongoClient
const client = new MongoClient(uri);

// Save a user to the database
const saveUser = async (userData) => {
  try {
    // Connect to MongoDB Atlas
    await client.connect();

    // Access the "users" collection in the database
    const collection = client.db('db').collection('users');

    // Insert the new user document into the collection
    const result = await collection.insertOne(userData);

    // Return the inserted user data
    return result.ops[0];
  } catch (error) {
    // Handle any errors
    console.error('Error saving user:', error);
    throw error;
  }
};

module.exports = { saveUser };
