// const express = require('express');
// const { MongoClient } = require('mongodb');

// const app = express();
// const port = 8081;

// // MongoDB Atlas connection string
// const uri = 'mongodb+srv://kabishek:KnyRKUFrM7hr9BXQ@cluster0.3vnej3o.mongodb.net/db?retryWrites=true&w=majority';

// // Create a new MongoClient
// const client = new MongoClient(uri);

// // Middleware to parse JSON requests
// app.use(express.json());

// // Define a POST route to insert a new user
// app.post('/api/users', async (req, res) => {
//   try {
//     // Extract user data from the request body
//     const { name, email, phone } = req.body;

//     // Connect to MongoDB Atlas
//     await client.connect();

//     // Access the "users" collection in the database
//     const collection = client.db('db').collection('users');

//     // Create a new user document
//     const newUser = { name, email, phone };

//     // Insert the new user document into the collection
//     const result = await collection.insertOne(newUser);

//     // Send a success response
//     res.status(201).json({ message: 'User created successfully', userId: result.insertedId });
//   } catch (error) {
//     // Handle any errors
//     console.error('Error inserting user:', error);
//     res.status(500).json({ message: 'Failed to insert user' });
//   }
// });

// // Start the server
// app.listen(port, () => {
//   console.log(`Server listening on port ${port}`);
// });


// server.js
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const usersRouter = require('./routes/users');

const app = express();
const PORT = 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Connect to MongoDB Atlas
mongoose.connect('mongodb+srv://kabishek:KnyRKUFrM7hr9BXQ@cluster0.3vnej3o.mongodb.net/db?retryWrites=true&w=majority', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB Atlas');
});

// Routes
app.use('/api/users', usersRouter);

// Start the server
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
