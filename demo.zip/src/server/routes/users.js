// routes/users.js
const express = require('express');
const router = express.Router();
const User = require('../models/userModels');

// Assuming you have an Express route handler for creating a new user
app.post('/api/users', async (req, res) => {
    const userData = req.body;
  
    try {
      // Save the user data
      const newUser = await User.create(userData);
  
      // Return the new user data in the response
      res.status(200).json(newUser);
    } catch (error) {
      if (error.name === 'ValidationError') {
        // Mongoose validation error occurred
        const errorData = {};
        for (let key in error.errors) {
          errorData[key] = error.errors[key].message;
        }
        res.status(400).json({ errors: errorData });
      } else {
        // Other server or database error occurred
        console.log('Failed to add user', error);
        res.status(500).json({ message: 'Failed to add user' });
      }
    }
  });
  
module.exports = router;
