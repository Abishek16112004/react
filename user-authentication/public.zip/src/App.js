import logo from './logo.svg';
import Paths from './routes/index';
function App() {
  return (
    <div className='container mt-0'>
    <Paths></Paths>
    </div>
  );
}

export default App;
