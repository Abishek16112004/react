
const Validate = (formData) => {

    let errors = {};
   

    if (formData.categoryName == "") {
        errors.categoryName = "Category name is required"
    }
    if (formData.categoryDescription == "") {
        errors.categoryDescription = "Category Description is required"
    }

    return errors;


}

export default Validate;