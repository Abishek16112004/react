
const Validate = (formData) => {

    let errors = {};
   

    if (formData.productName.trim() === "") {
        errors.productName = "Product name is required"
    }
    if (formData.productDescription.trim() === "") {
        errors.productDescription = "Product Description is required"
    }
    if (formData.productPrice.trim() === "") {
        errors.productPrice = "Product Price is required"
    }
    
    if (formData.productStock.trim() === "") {
        errors.productStock = "Product Stock is required"
    }

    if (formData.image === "") {
        errors.image = "Image is required"
    }

    return errors;


}

export default Validate;