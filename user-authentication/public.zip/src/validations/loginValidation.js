const validate = (values) => {

    let errors = {};
    const email_pattern = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g;
    
    
    if (values.email.trim() === "") {
        errors.email = "Email is required"
    }
    else if (!email_pattern.test(values.email.trim())) {
        errors.email = "Email format is invalid"
    }
   
    if (values.password.trim() === "") {
        errors.password = "Password is required"
    }
   

    return errors;
}

export default validate;