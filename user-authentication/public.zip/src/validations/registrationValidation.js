
const Validate = (formData) => {

    let errors = {};
    const email_pattern = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g;
    const phone_pattern = /^[6-9]{1}[0-9]{9}$/;

    if (formData.firstName.trim() === "") {
        errors.firstName = "First name is required"
    }
    if (formData.lastName.trim() === "") {
        errors.lastName = "Last name is required"
    }
    if (formData.email.trim() === "") {
        errors.email = "Email is required"
    }
    else if (!email_pattern.test(formData.email.trim())) {
        errors.email = "Email format is invalid"
    }
    if (formData.phoneNumber.trim() === "") {
        errors.phoneNumber = "Phone number is required"
    }
    else if (!phone_pattern.test(formData.phoneNumber.trim())) {
        errors.phoneNumber = "Phone number is invalid"
    }
    if (formData.password === "") {
        errors.password = "Password is required"
    }
    if (formData.confirmPassword === "") {
        errors.confirmPassword = "Confirm password is required"
    }
    else if (formData.password !== formData.confirmPassword) {
        errors.confirmPassword = "Password doesn't match"
    }
    if (formData.dob === "") {
        errors.dob = "Dob is required"
    }

    var option = document.getElementsByName('gender');

    if (!(option[0].checked || option[1].checked)) {
        errors.gender = "Gender is required"
    }


    var e = document.getElementById("department");
    var strUser = e.options[e.selectedIndex].value;
    //if you need text to be compared then use
    var strUser1 = e.options[e.selectedIndex].text;
    if (strUser == 0) //for text use if(strUser1=="Select")
    {
        errors.department = "Department is required"
    }

    if (formData.image === "") {
        errors.image = "Image is required"
    }

    return errors;


}

export default Validate;