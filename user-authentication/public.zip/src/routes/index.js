import { Redirect, BrowserRouter, Route, Routes } from 'react-router-dom';
import Registration from '../components/registration';
import Login from '../components/login';
import Home from '../components/home';
import Users from '../components/userListings';
import AddUsers from '../components/addUser';
import EditUser from '../components/editUser';
import { Navigate } from "react-router-dom";
import PageNotFound from '../components/PageNotFound';
import Admin from '../components/adminDetails';
import RegistrationTest from '../components/registrationTest';
import Products from '../components/products';
import AddProduct from '../components/addProduct';
import EditProduct from '../components/editProduct';
import HomePage from '../components/websiteMainPage'
import CartPage from '../components/productCart';
import Checkout from '../components/checkout';
import PaymentForm from '../components/payments'
import Orders from '../components/orders'
import OrdersList from '../components/ordersListing'
import TrackOrder from '../components/trackOrder'
import AdminLogin from '../components/adminLogin'
import AccountProfile from '../components/userProfile'
import Header from '../components/headerMain'
import Chat from '../components/chat';
import Categories from '../components/categories';
import AddCategories from '../components/addCategories';
import ForgotPassword from '../components/forgotPassword';
import ResetPassword from '../components/resetPassword';


const Paths = () => {
  const token = localStorage.getItem('token');
  const isAuthenticated = !!token; // Convert token to boolean value

  return (
    <BrowserRouter>
      <Routes>
        <Route exact path="/registration" element={<Registration />} />
        <Route exact path="/login" element={<Login />} />
        <Route exact path="/test" element={<RegistrationTest />} />
        <Route exact path="/" element={<HomePage />} />
        <Route exact path="/admin-login" element={<AdminLogin />} />
        <Route exact path="/cart" element={<CartPage />} />
        <Route exact path="/header" element={<Header />} />
        <Route exact path="/chat" element={<Chat />} />
        <Route exact path="/forgot-password" element={<ForgotPassword />} />
        <Route exact path="/reset-password" element={<ResetPassword />} />




        {isAuthenticated ? (
          <>
            <Route exact path="/Products" element={<Products />} />
            <Route exact path="/add-product" element={<AddProduct />} />
            <Route exact path="/editproduct/:id" element={<EditProduct />} />
            <Route exact path="/" element={<HomePage />} />
            <Route exact path="/cart" element={<CartPage />} />
            <Route exact path="/checkout" element={<Checkout />} />
            <Route exact path="/admin" element={<Home />} />
            <Route exact path="/users" element={<Users />} />
            <Route exact path="/admin-profile" element={<Admin />} />
            <Route exact path="/addusers" element={<AddUsers />} />
            <Route exact path="/edituser/:id" element={<EditUser />} />
            <Route exact path="/payment" element={<PaymentForm />} />
            <Route exact path="/orders" element={<Orders />} />
            <Route exact path="/orders-list" element={<OrdersList />} />
            <Route exact path="/track" element={<TrackOrder />} />
            <Route exact path="/user-profile" element={<AccountProfile />} />
            <Route exact path="/categories" element={<Categories />} />
            <Route exact path="/add-category" element={<AddCategories />} />
          </>
        ) : (
          <Route exact path="/admin" element={<PageNotFound />} />

        )}
      </Routes>
    </BrowserRouter>
  );
};

export default Paths;
