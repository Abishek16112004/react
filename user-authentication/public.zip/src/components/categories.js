import axios from 'axios';
import React, { useState, useEffect } from 'react';
import '../sidebar.css';
import Sidebar from './sidebar';
import { Item } from 'semantic-ui-react';
import { Link } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';
import { CSVLink } from 'react-csv';
import * as XLSX from 'xlsx';
import AddProduct from './addProduct';

const baseUrl = process.env.REACT_APP_SERVER_URL; // Access the base URL from .env

const Categories = () => {
    const [data, setData] = useState([]);
    const [filteredData, setFilteredData] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(5);
    const [searchQuery, setSearchQuery] = useState('');
    const [csvData, setCsvData] = useState([]);
    const [sortField, setSortField] = useState(null);
    const [sortOrder, setSortOrder] = useState('asc');
    const [isActive, setIsActive] = useState(false); // Define and initialize isActive state variable
    const [categoryCounts, setCategoryCounts] = useState({}); // Add categoryCounts state variable

    const loadData = async () => {
        const response = await axios.get(`${baseUrl}/category/get`);
        setData(response.data);
    };

    const loadCategoryCounts = async () => {
        try {
            const response = await axios.get(`${baseUrl}/count/category/get`);
            const counts = {};
            response.data.forEach((item) => {
                counts[item.category] = item.productCount;
            });
            setCategoryCounts(counts);
            console.log(counts); // Check the contents of categoryCounts
        } catch (error) {
            console.log(error);
            // Handle error
        }
    };
    
    
    useEffect(() => {
        loadData();
        loadCategoryCounts();
    }, []);

    useEffect(() => {
        const filteredItems = data.filter(
            (item) =>
                item.categoryName.toLowerCase().includes(searchQuery.toLowerCase())
        );
        setFilteredData(filteredItems);
        setCurrentPage(1);
    }, [searchQuery, data]);

    const navigate = useNavigate();

    const addCategories = () => {
        navigate('/add-category');
    }

    const deleteUser = (id) => {
        Swal.fire({
            title: 'Are you sure?',
            text: 'You want to delete this category',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!',
        }).then((result) => {
            if (result.isConfirmed) {
                navigate('/categories');
                axios.put(`${baseUrl}/category/delete/${id}`);
                Swal.fire(
                    'Deleted!',
                    'Category has been deleted! Please refresh your page',
                    'success'
                );
            }
        });
    };

    const generateCSVData = () => {
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Products csv file downloaded',
            showConfirmButton: false,
            timer: 1500
        })
        const csvData = filteredData.map((item) => ({
            Id: item.id,
            // 'Name': `${item.firstName}${item.lastName}`,
            CategoryName: item.categoryName,
            CategoryDescription: item.categoryDescription,
        }));

        setCsvData(csvData);
    };



    const handleSort = (field) => {
        let order = 'asc';
        if (sortField === field && sortOrder === 'asc') {
            order = 'desc';
        }
        setSortField(field);
        setSortOrder(order);

        const sortedData = [...filteredData].sort((a, b) => {
            const valueA = typeof a[field] === 'string' ? a[field].toLowerCase() : a[field];
            const valueB = typeof b[field] === 'string' ? b[field].toLowerCase() : b[field];

            if (valueA < valueB) {
                return order === 'asc' ? -1 : 1;
            }
            if (valueA > valueB) {
                return order === 'asc' ? 1 : -1;
            }
            return 0;
        });

        setFilteredData(sortedData);
        setCurrentPage(1);
    };



    const renderSortIcon = (field) => {
        if (field === sortField) {
            if (sortOrder === 'asc') {
                return <i className="fa-solid fa-arrow-up"></i>;
            } else {
                return <i className="fa-solid fa-arrow-down"></i>;
            }
        }
        return null;
    };

    const sortedItems = filteredData.slice().sort((a, b) => {
        if (sortField) {
            const fieldValueA = a[sortField].toLowerCase();
            const fieldValueB = b[sortField].toLowerCase();
            if (fieldValueA < fieldValueB) return sortOrder === 'asc' ? -1 : 1;
            if (fieldValueA > fieldValueB) return sortOrder === 'asc' ? 1 : -1;
        }
        return 0;
    });

    // Pagination
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = sortedItems.slice(indexOfFirstItem, indexOfLastItem);
    const totalPages = Math.ceil(filteredData.length / itemsPerPage);

    const handlePageChange = (pageNumber) => {
        setCurrentPage(pageNumber);
    };


    const handleActivate = (id) => {



        Swal.fire({
            title: 'Are you sure?',
            text: "You want to activate this category!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Activate it!'
        }).then((result) => {
            if (result.isConfirmed) {
                axios
                    .put(`${baseUrl}/category/activate/${id}`)
                    .then(() => setIsActive(true))
                    .catch((error) => {
                        console.log(error);
                        // Handle error
                    });
                Swal.fire(
                    'Activated!',
                    'Please referesh your page',
                    'success'
                )
            }
        })
    };
    const handleDeactivate = (id) => {
        Swal.fire({
            title: 'Are you sure?',
            text: "You want to de-activate this product!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Deactivate it!'
        }).then((result) => {
            if (result.isConfirmed) {
                axios
                    .put(`${baseUrl}/category/deactivate/${id}`)
                    .then(() => setIsActive(false))
                    .catch((error) => {
                        console.log(error);
                        // Handle error
                    });
                Swal.fire(
                    'Deactivated!',
                    'Please referesh your page',
                    'success'
                )
            }
        })

    };

    return (
        <>
            <Sidebar></Sidebar>
            <div>
                <main className="main">

                    <div id='exportbuttons'>
                        <div id='csv'>
                            <CSVLink data={csvData} onClick={generateCSVData} filename="products.csv">Export CSV</CSVLink>
                        </div>
                        <button id='excell' onClick={addCategories}><i class="fa-solid fa-plus"></i> Add Product</button>
                        <input
                            type="search"
                            placeholder="Search"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                    </div>
                    <table id="customers">
                        <thead>
                            <tr>
                                <th onClick={() => handleSort('id')}>Id {renderSortIcon('id')}</th>
                                <th onClick={() => handleSort('categoryName')}>Category Name {renderSortIcon('categoryName')}</th>
                                <th onClick={() => handleSort('categoryDescription')}>Category Description  {renderSortIcon('categoryDescription')}</th>
                                <th>Category (product Count)</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            {currentItems.map((item, index) => {
                                const sequentialId = (currentPage - 1) * itemsPerPage + index + 1;

                                return (
                                    <tr key={item.id}>
                                        <td>{sequentialId}</td>
                                        <td>{item.categoryName}</td>
                                        <td>{item.categoryDescription}</td>
                                        <td> {item.categoryName} ({categoryCounts[item.category] || 0})</td>
                                        <td>
                                            {item.status == 0 ? (
                                                <button onClick={() => handleDeactivate(item.id)} id="activate">Activate</button>
                                            ) : (
                                                <button onClick={() => handleActivate(item.id)} id="deactivate">Deactivate</button>
                                            )}
                                        </td>
                                        <td>
                                            <div id="icons">
                                                <Link to={`/editproduct/${item.id}`}>
                                                    <span>
                                                        <i className="fa-solid fa-pen-to-square"></i>
                                                    </span>
                                                </Link>
                                                <span>
                                                    <i className="fa-solid fa-trash" onClick={() => deleteUser(item.id)}></i>
                                                </span>
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}

                        </tbody>
                    </table>
                    <div id='pagination'>
                        <button id='previous' disabled={currentPage === 1} onClick={() => setCurrentPage(currentPage - 1)}>
                            Previous
                        </button>
                        <span>{currentPage} of {totalPages}</span>
                        <button id='next' disabled={currentPage === totalPages
                        } onClick={() => setCurrentPage(currentPage + 1)}>
                            Next
                        </button>
                    </div>
                </main>
            </div>
            <ToastContainer position="top-right" />
        </>
    );
};


export default Categories;
