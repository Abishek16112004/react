import { useState } from 'react'
import { Button, Checkbox, Form } from 'semantic-ui-react'
import validate from '../validations/loginValidation';
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import api from '../utils/registrationAxios';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Swal from 'sweetalert2'

const Login = () => {
    const initialValues = { email: "", password: "" };
    const [formValues, setFormValues] = useState(initialValues);
    const [formErrors, setFormErrors] = useState({});
    const [loginResponse, setLoginResponse] = useState({});

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormValues({ ...formValues, [name]: value });
    };

    const navigate = useNavigate();
    const handleBlur = (e) => {
        const fieldName = e.target.name;
        const errors = validate(formValues, fieldName);
        setFormErrors((prevErrors) => ({
            ...prevErrors,
            [fieldName]: errors[fieldName],
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        const errors = validate(formValues);
        setFormErrors(errors);

        if (Object.keys(errors).length === 0) {
            api.post('/login', formValues)
                .then(res => {
                    if (res.data.Login) {
                        localStorage.setItem("token", res.data.token);
                        localStorage.setItem("email", res.data.email);
                        localStorage.setItem("name", res.data.firstName);
                        localStorage.setItem("phone", res.data.phoneNumber);
                        localStorage.setItem("image", res.data.image);
                        setLoginResponse(res.data);
                        Swal.fire({
                            position: 'top-end',
                            icon: 'success',
                            title: 'Logged in successfully',
                            showConfirmButton: false,
                            timer: 1500
                        });

                    } else {
                        toast.error("Invalid username and password");
                    }
                })
                .catch(err => console.log(err));
        }
    };

    if (loginResponse.Login) {
        if (loginResponse.role == 'admin') {
            navigate('/admin'); // Redirect to the admin page
        } else {
            navigate('/'); // Redirect to the user page
        }
    }
    const Register = () => {
        navigate('/registration');
    };
    const Forgot = () => {
        navigate('/forgot-password');
    };

    return (
        <>
            <style>
                .container.mt-0 {"{"}
                background: aliceblue !important; padding-bottom: 199px;
                {"}"}
                input {"{"}
                width: 336px !important;
                {"}"}
            </style>
            <div className='container' id='login'>
                <Form onSubmit={handleSubmit}>
                    <h1 className='text-center'>Login Form</h1>
                    <Form.Field>
                        <label>Email</label>
                        <input type="text" name="email" id="email" placeholder='Email' value={formValues.email} onChange={handleChange} onBlur={handleBlur} />
                        <p className='error'>{formErrors.email}</p>
                    </Form.Field>
                    <Form.Field>
                        <label>Password</label>
                        <input type="password" name="password" id="password" placeholder='Password' value={formValues.password} onChange={handleChange} onBlur={handleBlur} />
                        <p className='error'>{formErrors.password}</p>
                    </Form.Field>
                    <div className="inline field">
                        <div className="ui">
                            <label>Create ! <a href="#" onClick={Register} id="loginhere"> New Account </a></label>
                            
                        </div>
                    </div>
                    <div className="inline field">
                        <div className="ui">
                            <label><a href="#" onClick={Forgot} id="loginhere" style={{float:"right", marginTop:"-29px"}}> Forgot Password </a></label>
                        </div>
                    </div>
                    <Button type='submit'>Submit</Button>
                </Form>
                <ToastContainer position="top-right" />
            </div>
        </>
    );
}

export default Login;
