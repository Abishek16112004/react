import React, { useState } from 'react';
import { Button, Checkbox, Form } from 'semantic-ui-react';
import Validate from '../validations/registrationValidation';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';
import api from '../utils/registrationAxios';
import '../form.css';
import axios from 'axios';
import Swal from 'sweetalert2';

const baseUrl = process.env.REACT_APP_SERVER_URL; // Access the base URL from .env

const Registration = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phoneNumber: '',
    password: '',
    confirmPassword: '',
    dob: '',
    gender: '',
    department: '',
    image: null,
    error: null
  });

  const [formErrors, setFormErrors] = useState({});
  const [serverErrors, setServerErrors] = useState({});

  const handleChange = (e) => {
    setFormData((prevFormData) => ({
      ...prevFormData,
      [e.target.name]: e.target.value,
    }));
  };
  const handleBlur = (e) => {
    const fieldName = e.target.name;
    const errors = Validate(formData, fieldName);
    setFormErrors((prevErrors) => ({
      ...prevErrors,
      [fieldName]: errors[fieldName],
    }));
  };

  const handleFileChange = (e) => {
    setFormData({ ...formData, image: e.target.files[0] });
  };

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    toast.warning('All fields are mandatory');
    const errors = Validate(formData);
    setFormErrors(errors);

    if (Object.keys(errors).length === 0) {
      const data = new FormData();
      data.append('firstName', formData.firstName);
      data.append('lastName', formData.lastName);
      data.append('email', formData.email);
      data.append('phoneNumber', formData.phoneNumber);
      data.append('password', formData.password);
      data.append('confirmPassword', formData.confirmPassword);
      data.append('dob', formData.dob);
      data.append('gender', formData.gender);
      data.append('department', formData.department);
      data.append('image', formData.image);


      try {
        const a = await axios.post(`${baseUrl}/registration`, data);

        Swal.fire({
          position: 'top-end',
          icon: 'success',
          title: 'Congratulations! Your account has been created successfully',
          showConfirmButton: false,
          timer: 1500,
        });
        navigate('/login');
      } catch (err) {

        if (err && err.response && err.response.status === 400) {
          console.log("errttt", err);
          const serverValidationErrors = {};
          // err.response.data.errors.forEach((error) => {
          //   serverValidationErrors[error.param] = error.msg;
          // });
          setServerErrors(err?.response?.data?.errors);

          console.log("serverErrors", serverErrors);
        } else {
          console.log(err);
        }
      }
    }
  };

  const Login = () => {
    navigate('/login');
  };

  return (
    <>
      <style>
        input {"{"}
        width: 350px !important;
        {"}"}
      </style>
      <div className='container' id='test'>
        <h1>Registration Form</h1>
        <form onSubmit={handleSubmit} enctype="multipart/form-data" >

          <div className="ui inverted segment">
            <div className="ui inverted form">
              <div className="two fields">
                <div className="field">
                  <label>First Name</label>
                  <input type="text" name="firstName" id="first-name" placeholder='First Name' value={formData.firstName} onChange={handleChange} onBlur={handleBlur} />
                  <p className='error'>{formErrors.firstName}</p>
                  <p className="error">{serverErrors.firstName}</p>
                </div>
                <div className="field">
                  <label>Last Name</label>
                  <input type="text" name="lastName" id="last-name" placeholder='Last Name' value={formData.lastName} onChange={handleChange} onBlur={handleBlur} />
                  <p className='error'>{formErrors.lastName}</p>
                  <p className="error">{serverErrors.lastName}</p>
                </div>
              </div>
              <div className="two fields">
                <div className="field">
                  <label>Email</label>
                  <input type="text" name="email" id="email" placeholder='Email' value={formData.email} onChange={handleChange} onBlur={handleBlur} />
                  <p className='error'>{formErrors.email}</p>
                  <p className="error">{serverErrors.email}</p>
                </div>
                <div className="field">
                  <label>Phone Number</label>
                  <input type="text" name="phoneNumber" id="phone-number" placeholder='Phone Number' value={formData.phoneNumber} onChange={handleChange} onBlur={handleBlur} />
                  <p className='error'>{formErrors.phoneNumber}</p>
                  <p className="error">{serverErrors.phoneNumber}</p>

                </div>
              </div>
              <div className="two fields">
                <div className="field">
                  <label>Password</label>
                  <input type="password" name="password" id="password" placeholder='Password' value={formData.password} onChange={handleChange} onBlur={handleBlur} />
                  <p className='error'>{formErrors.password}</p>
                  <p className="error">{serverErrors.password}</p>

                </div>
                <div className="field">
                  <label>Confirm Password</label>
                  <input type="password" name="confirmPassword" id="confirmPassword" placeholder='Confirm Password' value={formData.confirmPassword} onChange={handleChange} onBlur={handleBlur} />
                  <p className='error'>{formErrors.confirmPassword}</p>
                  <p className="error">{serverErrors.confirmPassword}</p>
                </div>
              </div>
              <div className="two fields">
                <div className="field">
                  <label>Date Of Birth</label>
                  <input type="date" name="dob" id="dob" placeholder='Date of birth' value={formData.dob} onChange={handleChange} onBlur={handleBlur} />
                  <p className='error'>{formErrors.dob}</p>
                  <p className="error">{serverErrors.dob}</p>
                </div>
                <div className="field">
                  <label>Department</label>
                  <select name="department" id="department" onChange={handleChange} onBlur={handleBlur}>
                    <option value="" selected disabled hidden>Select an Option</option>
                    <option value="Hr Department">Hr Department</option>
                    <option value="Software Engineering">Software Engineering</option>
                    <option value="Technical Support">Technical Support</option>
                    <option value="Digital Marketing">Digital Marketing</option>
                  </select>
                  <p className='error'>{formErrors.department}</p>
                  <p className="error">{serverErrors.department}</p>
                </div>
              </div>
              <div className="two fields">
                <div className="field">
                  <label>Upload</label>
                  <input type="file" name="image" onChange={handleFileChange} onBlur={handleBlur} /><br />
                  <p className='error'>{formErrors.image}</p>
                  <p className="error">{serverErrors.image}</p>
                </div>
                <div className="field">
                  <label>Gender : </label>
                  <div id="radio-inline">

                    <input type="radio" id="male" name="gender" value="Male" onChange={handleChange} onBlur={handleBlur} />
                    <label for="html">Male</label><br />
                    <input type="radio" id="female" name="gender" value="Femaler" onChange={handleChange} onBlur={handleBlur} />
                    <label for="css">Female</label><br />
                    <input type="radio" id="other" name="gender" value="Other" onChange={handleChange} onBlur={handleBlur} />
                    <label for="javascript">Other</label><br />
                  </div>
                  <p className='error'>{formErrors.gender}</p>
                  <p className="error">{serverErrors.gender}</p>
                </div>
              </div>
              <br />
              <div className="inline field">
                <div className="ui">
                  <label>If you have already account ! <a href="#" onClick={Login} id="loginhere"> Login Here </a></label>
                </div>
              </div>
              <Button type='submit' >Submit</Button>

            </div>
          </div>
        </form>

        <ToastContainer position="top-right" />

      </div>
    </>

  )
}

export default Registration



