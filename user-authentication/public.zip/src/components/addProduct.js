import { useState, useEffect } from 'react';
import { Button, Form } from 'semantic-ui-react';
import Validate from '../validations/productaddValidation';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';
import api from '../utils/registrationAxios';
import '../form.css';
import axios from 'axios';
import Swal from 'sweetalert2';
import '../sidebar.css';
import Sidebar from './sidebar';

const baseUrl = process.env.REACT_APP_SERVER_URL; // Access the base URL from .env

const AddProduct = () => {
  const [formData, setFormData] = useState({
    productName: '',
    productDescription: '',
    productPrice: '',
    productStock: '',
    image: null,
    categoryId: '',
  });
  const [formErrors, setFormErrors] = useState({});
  const [categories, setCategories] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch categories from the server and update the state
    const fetchCategories = async () => {
      try {
        const response = await axios.get(`${baseUrl}/categories`);
        setCategories(response.data);
      } catch (error) {
        console.log(error);
      }
    };

    
    fetchCategories();
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    setFormData({ ...formData, image: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    toast.warning('All fields are mandatory');
    const errors = Validate(formData);
    setFormErrors(errors);
    if (Object.keys(errors).length === 0) {
      const data = new FormData();
      data.append('productName', formData.productName);
      data.append('productDescription', formData.productDescription);
      data.append('productPrice', formData.productPrice);
      data.append('productStock', formData.productStock);
      data.append('image', formData.image);
      data.append('categoryId', formData.categoryId);

      try {
        await axios.post(`${baseUrl}/product`, data);
        Swal.fire({
          position: 'top-end',
          icon: 'success',
          title: 'Congratulation! New Product created successfully',
          showConfirmButton: false,
          timer: 1500,
        });
        navigate('/products');
      } catch (err) {
        console.log(err);
      }
    }
  };

  return (
    <>
      <Sidebar></Sidebar>
      <main className="main">
        <div className="container" id="containwidth">
          <Form onSubmit={handleSubmit} encType="multipart/form-data">
            <h1 className="text-center">Add Product</h1>
            <Form.Field required>
              <label>Product Name</label>
              <input
                type="text"
                name="productName"
                id="product-name"
                placeholder="Product Name"
                value={formData.productName}
                onChange={handleChange}
              />
              <p className="error">{formErrors.productName}</p>
            </Form.Field>
            <Form.Field required>
              <label>Product Description</label>
              <input
                type="text"
                name="productDescription"
                id="product-description"
                placeholder="Product Description"
                value={formData.productDescription}
                onChange={handleChange}
              />
              <p className="error">{formErrors.productDescription}</p>
            </Form.Field>
            <Form.Field required>
              <label>Product Price</label>
              <input
                type="text"
                name="productPrice"
                id="product-price"
                placeholder="Price ₹"
                value={formData.productPrice}
                onChange={handleChange}
              />
              <p className="error">{formErrors.productPrice}</p>
            </Form.Field>
            <Form.Field required>
              <label>Product Stock Quantity</label>
              <input
                type="number"
                name="productStock"
                id="product-stock"
                placeholder="Stock"
                value={formData.productStock}
                onChange={handleChange}
              />
              <p className="error">{formErrors.productStock}</p>
            </Form.Field>
            <Form.Field required>
              <label>Product Category</label>
              <select
                name="categoryId"
                value={formData.categoryId}
                onChange={handleChange}
              >
                <option value="">Select Category</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.categoryName}
                  </option>
                ))}
              </select>
              <p className="error">{formErrors.categoryId}</p>
            </Form.Field>
            <Form.Field required>
              <label>Product Image Upload</label>
              <input type="file" name="image" onChange={handleFileChange} />
              <br />
              <p className="error">{formErrors.image}</p>
            </Form.Field>
            <Button type="submit">Submit</Button>
          </Form>
          <ToastContainer position="top-right" />
        </div>
      </main>
    </>
  );
};

export default AddProduct;
