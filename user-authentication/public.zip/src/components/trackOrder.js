import React, { useEffect, useState } from 'react';

const TrackOrder = () => {
    const [orderStatus, setOrderStatus] = useState('');
    const [trackingNumber, setTrackingNumber] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Simulate fetching order information from the server
        fetchOrderInformation()
            .then((response) => {
                setOrderStatus(response.status);
                setTrackingNumber(response.trackingNumber);
                setLoading(false);
            })
            .catch((error) => {
                console.error('Error fetching order information:', error);
                setLoading(false);
            });
    }, []);

    const fetchOrderInformation = () => {
        // Simulated API call to fetch order information
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                const response = {
                    status: 'Shipped',
                    trackingNumber: '123456789',
                };
                resolve(response);
            }, 2000); // Simulating delay of 2 seconds
        });
    };

    return (
        <div>
            <h2>Track Your Order</h2>
            {loading ? (
                <div>Loading...</div>
            ) : (
                <>
                    <div>
                        <strong>Order Status:</strong> {orderStatus}
                    </div>
                    <div>
                        <strong>Tracking Number:</strong> {trackingNumber}
                    </div>
                </>
            )}
        </div>
    );
};

export default TrackOrder;
