import { useState } from 'react'
import { Button, Checkbox, Form } from 'semantic-ui-react'
import Validate from '../validations/registrationValidation';
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';
import api from '../utils/registrationAxios';
import '../form.css';
import axios from 'axios';
import Swal from 'sweetalert2'
import '../sidebar.css'
import Sidebar from './sidebar'

const baseUrl = process.env.REACT_APP_SERVER_URL; // Access the base URL from .env

const Registration = () => {
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        phoneNumber: '',
        password: '',
        dob: '',
        gender: '',
        department: '',
        image: null,
    });
    const [formErrors, setFormErrors] = useState({});

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleFileChange = (e) => {
        setFormData({ ...formData, image: e.target.files[0] });
    };
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        toast.warning("All fields are mandatory")
        const errors = Validate(formData);
        setFormErrors(errors);
        if (Object.keys(errors).length === 0) {
            const data = new FormData();
            data.append('firstName', formData.firstName);
            data.append('lastName', formData.lastName);
            data.append('email', formData.email);
            data.append('phoneNumber', formData.phoneNumber);
            data.append('password', formData.password);
            data.append('dob', formData.dob);
            data.append('gender', formData.gender);
            data.append('department', formData.department);
            data.append('image', formData.image);

            try {
                await axios.post(`${baseUrl}/registration`, data);
                Swal.fire({
                    position: 'top-end',
                    icon: 'success',
                    title: 'Congratulation! New user created successfully  ',
                    showConfirmButton: false,
                    timer: 1500
                })
                navigate('/users');
            } catch (err) {
                console.log(err);
            }
        }
    };


    return (
        <>
            <Sidebar></Sidebar>

            <main className="main">

                <div className='container' id='containwidth'>

                    <Form onSubmit={handleSubmit} enctype="multipart/form-data">
                        <h1 className='text-center'>Add User</h1>
                        <Form.Field required>
                            <label>First Name</label>
                            <input type="text" name="firstName" id="first-name" placeholder='First Name' value={formData.firstName} onChange={handleChange} />
                            <p className='error'>{formErrors.firstName}</p>
                        </Form.Field>
                        <Form.Field required>
                            <label>Last Name</label>
                            <input type="text" name="lastName" id="last-name" placeholder='Last Name' value={formData.lastName} onChange={handleChange} />
                            <p className='error'>{formErrors.lastName}</p>
                        </Form.Field>
                        <Form.Field required>
                            <label>Email</label>
                            <input type="text" name="email" id="email" placeholder='Email' value={formData.email} onChange={handleChange} />
                            <p className='error'>{formErrors.email}</p>
                        </Form.Field>
                        <Form.Field required>
                            <label>Phone Number</label>
                            <input type="text" name="phoneNumber" id="phone-number" placeholder='Phone Number' value={formData.phoneNumber} onChange={handleChange} />
                            <p className='error'>{formErrors.phoneNumber}</p>
                        </Form.Field>
                        <Form.Field required>
                            <label>Password</label>
                            <input type="password" name="password" id="password" placeholder='Password' value={formData.password} onChange={handleChange} />
                            <p className='error'>{formErrors.password}</p>
                        </Form.Field>
                        <Form.Field required >
                            <label>Confirm Password</label>
                            <input type="password" name="confirmPassword" id="first-name" placeholder='Confirm Password' value={formData.confirmPassword} onChange={handleChange} />
                            <p className='error'>{formErrors.confirmPassword}</p>
                        </Form.Field>
                        <Form.Field required>
                            <label>Date Of Birth</label>
                            <input type="date" name="dob" id="dob" placeholder='Date of birth' value={formData.dob} onChange={handleChange} />
                            <p className='error'>{formErrors.dob}</p>
                        </Form.Field>
                        <Form.Field id="radio-inline"  >
                            <label>Gender : </label>
                            <input type="radio" id="male" name="gender" value="Male" onChange={handleChange} />
                            <label for="html">Male</label><br />
                            <input type="radio" id="female" name="gender" value="Femaler" onChange={handleChange} />
                            <label for="css">Female</label><br />
                            <input type="radio" id="other" name="gender" value="Other" onChange={handleChange} />
                            <label for="javascript">Other</label>
                            <p className='error'>{formErrors.gender}</p>

                        </Form.Field>
                        <Form.Field>
                            <label>Department</label>
                            <select name="department" id="department" onChange={handleChange}>
                                <option value="" selected disabled hidden>Select an Option</option>
                                <option value="Hr Department">Hr Department</option>
                                <option value="Software Engineering">Software Engineering</option>
                                <option value="Technical Support">Technical Support</option>
                                <option value="Digital Marketing">Digital Marketing</option>
                            </select>
                            <p className='error'>{formErrors.department}</p>
                        </Form.Field>
                        <Form.Field required>
                            <label>Upload</label>
                            <input type="file" name="image" onChange={handleFileChange} /><br />
                            <p className='error'>{formErrors.image}</p>

                        </Form.Field>

                        <Button type='submit' >Submit</Button>
                    </Form>
                    <ToastContainer position="top-right" />
                </div>
            </main>
        </>
    )
}

export default Registration