import React from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const PageNotFound = () => {
    toast.error("You are not authorised")


    return (
        <>

            <ToastContainer position="top-right" />
        </>
    )
}

export default PageNotFound;