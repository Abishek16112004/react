import '../homePage.css';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import FormatPrice from '../components/formatCurrency'

const baseUrl = process.env.REACT_APP_SERVER_URL; // Access the base URL from .env

const HomePage = () => {
    const [data, setData] = useState([]);
    const [cartItems, setCartItems] = useState(() => {
        const storedCartItems = localStorage.getItem('cartItems');
        return storedCartItems ? JSON.parse(storedCartItems) : [];
    });

    const handleLogout = () => {
        Swal.fire(
            'Logout Successfully!',
            '',
            'success'
          )
        // Make an API call to the logout endpoint on the server

        // Clear token from localStorage
        localStorage.removeItem('token');
        localStorage.removeItem('id');
        localStorage.removeItem('email');
        localStorage.removeItem('cartItems');
        // Redirect the user to the login page
        navigate('/');

    }
    const loadData = async () => {
        const response = await axios.get(`${baseUrl}/products/get`);
        setData(response.data);
    };

    useEffect(() => {
        loadData();
    }, []);

    // const addToCart = (item) => {
    //     toast.success("Product added successfully");
    //     setCartItems([...cartItems, item]);
    //     const updatedCartItems = [...cartItems, item];
    //     localStorage.setItem('cartItems', JSON.stringify(updatedCartItems));
    // };
    const addToCart = (item) => {
        const existingItem = cartItems.find((cartItem) => cartItem.id === item.id);

        if (existingItem) {
            toast.info("Product already exists in the cart");
            return;
        }

        toast.success("Product added successfully");
        setCartItems([...cartItems, item]);
        const updatedCartItems = [...cartItems, item];
        localStorage.setItem("cartItems", JSON.stringify(updatedCartItems));
    };

    const navigate = useNavigate();

    const CartRedirect = () => {
        navigate('/cart');
    }
    const Regsitration = () => {
        navigate('/registration');
    }
    const Profile = () => {
        navigate('/user-profile');
    }
    const token = localStorage.getItem('token');
    const isAuthenticated = !!token; // Convert token to boolean value
    return (
        <>
            {/* Navigation Bar */}
            <div className="w3-bar w3-white w3-border-bottom w3-xlarge">
                <a href="#" className="w3-bar-item w3-button w3-text-red w3-hover-red">
                    <b>
                        <i className="fa fa-map-marker w3-margin-right" /> Logo
                    </b>
                </a>
                <div id='userMenu'>
                    <a href="">Register</a>

                </div>

                <a href="#" className="w3-bar-item w3-button w3-right w3-hover-red w3-text-grey">
                    {isAuthenticated ? (
                        <a href="" onClick={Profile}><i class="fa-solid fa-user"></i></a>


                    ) : (
                        <a href="" onClick={Regsitration}><i class="fa-solid fa-user"></i></a>

                    )}
                    <a href="" onClick={CartRedirect}><i class="fa-solid fa-cart-shopping" id='cart'><span class="w3-badge">{cartItems.length}</span></i></a>
                    <i class="fa-solid fa-truck-fast"></i>
                </a>
            </div>

            {/* Page content */}
            <div className="w3-content" style={{ maxWidth: 2000, marginTop: 0 }}>
                {/* Automatic Slideshow Images */}
                <div className="mySlides w3-display-container w3-center">
                    {/* <img src="https://img.freepik.com/free-vector/template-banner-online-store-with-shopping-cart-with-purchases-boxes-delivery-from-supermarket-vector-illustration_548887-104.jpg?w=2000" id='overlay' style={{ width: "100%" }} /> */}
                    <iframe
                        width="1920"
                        height="800"
                        src="https://www.youtube.com/embed/WoaAMzG31P4?&autoplay=5?start=4"
                        title="YouTube video player"
                        frameborder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowfullscreen
                    ></iframe>
                </div>
            </div>

            <h1 id="heading">Our Products</h1>

            {/* <div className="product-container" >
        {data.map((item, index) => (
          <div key={index} className="card" >
            <img src={`http://localhost:8081/uploads/${item.image}`} alt="Denim Jeans" style={{ width: "100%", height : "200px" }} />
            <h1>{item.productName}</h1>
            <p className="price">₹{item.productPrice}</p>
            <p>{item.productDescription}</p>
            <p>
              <button>Add to Cart</button>
            </p>
          </div>
        ))}
      </div> */}
            <div className="product-container">
                {data.map((item, index) => (
                    <div key={index} className="product-card">
                        <img
                            src={`http://localhost:8081/uploads/${item.image}`}
                            alt="Denim Jeans"
                            className="product-image"
                        />
                        <h1 style={{ fontSize: "18px" }}>{item.productName}</h1>
                        <p>{item.productDescription}</p>
                        {/* <p className="price">{FormatPrice.item.productPrice}</p> */}
                        <p className="price"><FormatPrice price={item.productPrice} /></p>

                        <p>
                            <button onClick={() => addToCart(item)} style={{ borderRadius: "20px", width: "150px" }} id="addToCart">Add to Cart</button>

                        </p>
                    </div>
                ))}
            </div>

            <br />
            <br />
            <br />

            <footer class="w3-center w3-light-grey w3-padding-32">
                <p>
                    Powered by <a href="" target="_blank" class="w3-hover-text-green">Digital</a>
                </p>
            </footer>
            <ToastContainer position="top-right" />

        </>
    );
};

export default HomePage;
