const RegistrationTest = () => {

  return (
    <div class="ui mini form">
      <div class="two fields">
        <div class="field">
          <label>First Name</label>
          <input placeholder="First Name" type="text" />
        </div>
        <div class="field">
          <label>Last Name</label>
          <input placeholder="Last Name" type="text" />
        </div>
      </div>
      <div class="ui submit button">Submit</div>
    </div>

  )
}

export default RegistrationTest;