import { useHistory } from 'react-router-dom';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Products from './products';


const Sidebar = () => {


    const navigate = useNavigate();
    const handleLogout = () => {

        // Make an API call to the logout endpoint on the server

        // Clear token from localStorage
        localStorage.removeItem('token');
        localStorage.removeItem('id');
        localStorage.removeItem('email');
        localStorage.removeItem('cartItems');
        // Redirect the user to the login page
        navigate('/login');

    }
    const Dashboard = () => {
        navigate('/admin');
    }
    const Users = () => {
        navigate('/users');
    }
    const AddUsers = () => {
        navigate('/addusers');
    }
    const Admin = () => {
        navigate('/admin-profile');
    }
    const Products = () => {
        navigate('/products');
    }
    const Orders = () => {
        navigate('/orders-list');
    }
    const Categories = () => {
        navigate('/categories');
    }
    return (
        <>
            <nav className="sidebar">
                <a href="#" className="logo">
                    <img src="https://cdn-icons-png.flaticon.com/512/7211/7211037.png" alt="" width="80px" />
                    <h2>Welcome Admin</h2>
                </a>
                <div className="menu-content">
                    <ul className="menu-items">

                        <li className="item">
                            <a href="" onClick={Dashboard}><img src="https://cdn-icons-png.flaticon.com/512/4725/4725681.png" width={25} alt="" /> Dashboard</a>
                        </li>
                        <li className="item">
                            <a href="" onClick={Users}><img src="https://cdn-icons-png.flaticon.com/512/747/747545.png" width={25} alt="" /> Users</a>
                        </li>
                        {/* <li className="item">
                            <a href="" onClick={AddUsers}><i class="fa-solid fa-user-plus"></i> Add Users</a>
                        </li> */}
                        <li className="item">
                            <a href="" onClick={Products}><img src="https://cdn-icons-png.flaticon.com/512/10543/10543163.png" width={25} alt="" /> Products</a>
                        </li>
                        <li className="item">
                            <a href="" onClick={Categories}><img src="https://cdn-icons-png.flaticon.com/512/1621/1621169.png" width={25} alt="" /> Categories</a>
                        </li>
                        <li className="item">
                            <a href="" onClick={Orders}><img src="https://cdn-icons-png.flaticon.com/512/872/872243.png" width={25} alt="" /> Orders</a>
                        </li>
                        <li className="item">
                            <a href="" onClick={Admin}> <img src="https://cdn-icons-png.flaticon.com/512/747/747474.png" width={25} alt="" /> Admin</a>
                        </li>
                        <li className="item">
                            <a href="" onClick={handleLogout}><img src="https://cdn-icons-png.flaticon.com/512/1287/1287004.png" width={25} alt="" /> Logout</a>

                        </li>
                        <br /><br />
                        <br /><br />
                        <iframe width="250" height="250" src="https://www.youtube.com/embed/BsDoLVMnmZs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                    </ul>
                </div>
            </nav>
            <nav className="navbar">
                <i className="fa-solid fa-bars" id="sidebar-close" />
            </nav>
        </>
    )
}

export default Sidebar;