import axios from 'axios';
import React, { useEffect, useState } from 'react';
import '../sidebar.css';
import Sidebar from './sidebar';

const baseUrl = process.env.REACT_APP_SERVER_URL; // Access the base URL from .env

const Home = () => {
    const [dashboardData, setDashboardData] = useState(null);

    useEffect(() => {
        fetchDashboardData();
    }, []);

    const fetchDashboardData = () => {
        axios
            .get(`${baseUrl}/dashboardData`)
            .then((response) => {
                setDashboardData(response.data);
            })
            .catch((error) => {
                console.error('Error fetching dashboard data:', error);
            });
    };

    return (
        <>
            <style>
                .product-card &#123;
                width: calc(25% - 20px);
                margin-bottom: 20px;
                padding: 10px;
                border: 1px solid #ccc;
                text-align: center;
                background-color: white;
                transition: 1s;
                width: 300px;
                &#125;
                p {"{"}
                font-size: 30px; font-weight: 800;
                {"}"}
                .product-container {"{"}
                display: flex; flex-wrap: wrap; justify-content: space-between; width: 80%;
                margin: 0 auto;
                margin-top:-180px;
                {"}"}
            </style>
            <Sidebar></Sidebar>
            <main className="main">
                <h1>Admin Dashboard Content</h1>

                {dashboardData && (
                    <div className="product-container">
                        <div className="product-card">
                            <img src="https://cdn-icons-png.flaticon.com/512/3502/3502601.png" alt="" width="50" />
                            <h1 style={{ fontSize: '18px' }}>Total Products</h1>
                            <p>{dashboardData.totalProducts}</p>
                        </div>
                        <div className="product-card">
                            <img src="https://cdn-icons-png.flaticon.com/512/347/347674.png" alt="" width="50" />
                            <h1 style={{ fontSize: '18px' }}>Total Categories</h1>
                            <p>{dashboardData.totalCategories}</p>
                        </div>
                        <div className="product-card">
                            <img src="https://cdn-icons-png.flaticon.com/512/3310/3310240.png" alt="" width="50" />
                            <h1 style={{ fontSize: '18px' }}>Total Customers</h1>
                            <p>{dashboardData.totalCustomers}</p>
                        </div>
                        <div className="product-card">
                            <img src="https://cdn-icons-png.flaticon.com/512/6815/6815043.png" alt="" width="50" />
                            <h1 style={{ fontSize: '18px' }}>Total Orders</h1>
                            <p>{dashboardData.totalOrders}</p>
                        </div>
                        <div className="product-card">
                            <img src="https://cdn-icons-png.flaticon.com/512/10265/10265651.png" alt="" width="50" />
                            <h1 style={{ fontSize: '18px' }}>Completed Orders</h1>
                            <p>{dashboardData.completedOrders}</p>
                        </div>
                        <div className="product-card">
                            <img src="https://cdn-icons-png.flaticon.com/512/8903/8903151.png" alt="" width="50" />
                            <h1 style={{ fontSize: '18px' }}>Pending Orders</h1>
                            <p>{dashboardData.pendingOrders}</p>
                        </div>
                    </div>
                )}
            </main>
        </>
    );
};

export default Home;
