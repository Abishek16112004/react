import { useState } from 'react'
import { Button, Checkbox, Form } from 'semantic-ui-react'
import Validate from '../validations/categoryaddValidation';
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';
import api from '../utils/registrationAxios';
import '../form.css';
import axios from 'axios';
import Swal from 'sweetalert2'
import '../sidebar.css'
import Sidebar from './sidebar'

const baseUrl = process.env.REACT_APP_SERVER_URL; // Access the base URL from .env

const AddProduct = () => {
    const [formData, setFormData] = useState({
        categoryName: '',
        categoryDescription: '',
    });
    const [formErrors, setFormErrors] = useState({});

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };


    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        toast.warning("All fields are mandatory")
        const errors = Validate(formData);
        setFormErrors(errors);
        if (Object.keys(errors).length === 0) {
            try {
                await axios.post(`${baseUrl}/category`, formData);
                Swal.fire({
                    position: 'top-end',
                    icon: 'success',
                    title: 'Congratulation! New Product created successfully  ',
                    showConfirmButton: false,
                    timer: 1500
                })
                navigate('/products');
            } catch (err) {
                console.log(err);
            }
        }
    };

    return (
        <>
            <Sidebar></Sidebar>

            <main className="main">

                <div className='container' id='containwidth'>

                    <Form onSubmit={handleSubmit} enctype="multipart/form-data">
                        <h1 className='text-center'>Add Product</h1>
                        <Form.Field required>
                            <label>Product Name</label>
                            <input type="text" name="categoryName" id="product-name" placeholder='Product Name' value={formData.categoryName} onChange={handleChange} />
                            <p className='error'>{formErrors.productName}</p>
                        </Form.Field>
                        <Form.Field required>
                            <label>Product Description</label>
                            <input type="text" name="categoryDescription" id="product-description" placeholder='Product Description' value={formData.categoryDescription} onChange={handleChange} />
                            <p className='error'>{formErrors.productDescription}</p>
                        </Form.Field>


                        <Button type='submit' >Submit</Button>
                    </Form>
                    <ToastContainer position="top-right" />
                </div>
            </main>
        </>
    )
}

export default AddProduct