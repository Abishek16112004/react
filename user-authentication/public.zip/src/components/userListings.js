import axios from 'axios';
import React, { useState, useEffect } from 'react';
import '../sidebar.css';
import Sidebar from './sidebar';
import { Item } from 'semantic-ui-react';
import { Link } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';
import { CSVLink } from 'react-csv';
import * as XLSX from 'xlsx';

const baseUrl = process.env.REACT_APP_SERVER_URL; // Access the base URL from .env

const Users = () => {
    const [data, setData] = useState([]);
    const [filteredData, setFilteredData] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(5);
    const [searchQuery, setSearchQuery] = useState('');
    const [csvData, setCsvData] = useState([]);
    const [sortField, setSortField] = useState(null);
    const [sortOrder, setSortOrder] = useState('asc');


    const loadData = async () => {
        const response = await axios.get(`${baseUrl}/api/get`);
        setData(response.data);
    };

    useEffect(() => {
        loadData();
    }, []);

    useEffect(() => {
        const filteredItems = data.filter(
            (item) =>
                item.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                item.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                item.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                item.phoneNumber.toLowerCase().includes(searchQuery.toLowerCase())
        );
        setFilteredData(filteredItems);
        setCurrentPage(1);
    }, [searchQuery, data]);

    const navigate = useNavigate();

    const deleteUser = (id) => {
        Swal.fire({
            title: 'Are you sure?',
            text: 'You want to delete this user',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!',
        }).then((result) => {
            if (result.isConfirmed) {
                navigate('/users');
                axios.put(`${baseUrl}/api/delete/${id}`);
                Swal.fire(
                    'Deleted!',
                    'User has been deleted! Please refresh your page',
                    'success'
                );
            }
        });
    };

    const generateCSVData = () => {
        const csvData = filteredData.map((item) => ({
            Id: item.id,
            Image: item.image,
            // 'Name': `${item.firstName}${item.lastName}`,
            Name: [item.firstName, item.lastName].join(', '),
            Email: item.email,
            'Phone Number': item.phoneNumber,
        }));

        setCsvData(csvData);
    };

    const exportExcelData = () => {
        const worksheet = XLSX.utils.json_to_sheet(filteredData);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Users');
        const excelData = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        const data = new Blob([excelData], { type: 'application/octet-stream' });
        const url = URL.createObjectURL(data);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'users.xlsx');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleSort = (field) => {
        let order = 'asc';
        if (sortField === field && sortOrder === 'asc') {
            order = 'desc';
        }
        setSortField(field);
        setSortOrder(order);

        const sortedData = [...filteredData].sort((a, b) => {
            const valueA = typeof a[field] === 'string' ? a[field].toLowerCase() : a[field];
            const valueB = typeof b[field] === 'string' ? b[field].toLowerCase() : b[field];

            if (valueA < valueB) {
                return order === 'asc' ? -1 : 1;
            }
            if (valueA > valueB) {
                return order === 'asc' ? 1 : -1;
            }
            return 0;
        });

        setFilteredData(sortedData);
        setCurrentPage(1);
    };



    const renderSortIcon = (field) => {
        if (field === sortField) {
            if (sortOrder === 'asc') {
                return <i className="fa-solid fa-arrow-up"></i>;
            } else {
                return <i className="fa-solid fa-arrow-down"></i>;
            }
        }
        return null;
    };

    const sortedItems = filteredData.slice().sort((a, b) => {
        if (sortField) {
            const fieldValueA = a[sortField].toLowerCase();
            const fieldValueB = b[sortField].toLowerCase();
            if (fieldValueA < fieldValueB) return sortOrder === 'asc' ? -1 : 1;
            if (fieldValueA > fieldValueB) return sortOrder === 'asc' ? 1 : -1;
        }
        return 0;
    });

    // Pagination
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = sortedItems.slice(indexOfFirstItem, indexOfLastItem);
    const totalPages = Math.ceil(filteredData.length / itemsPerPage);

    const handlePageChange = (pageNumber) => {
        setCurrentPage(pageNumber);
    };

    return (
        <>
            <Sidebar></Sidebar>
            <div>
                <main className="main">

                    <div id='exportbuttons'>
                        <div id='csv'>
                            <CSVLink data={csvData} onClick={generateCSVData} filename="users.csv">Export CSV</CSVLink>
                        </div>
                        <button id='excell' onClick={exportExcelData}>Export Excell</button>
                        <input
                            type="search"
                            placeholder="Search"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                    </div>
                    <table id="customers">
                        <thead>
                            <tr>
                                <th onClick={() => handleSort('id')}>Id {renderSortIcon('id')}</th>
                                <th>Image</th>
                                <th onClick={() => handleSort('firstName')}>First Name {renderSortIcon('firstName')}</th>
                                <th onClick={() => handleSort('lastName')}>Last Name {renderSortIcon('lastName')}</th>
                                <th onClick={() => handleSort('email')}>Email {renderSortIcon('email')}</th>
                                <th onClick={() => handleSort('phoneNumber')}>Phone Number {renderSortIcon('phoneNumber')}</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            {currentItems.map((item, index) => {
                                const sequentialId = (currentPage - 1) * itemsPerPage + index + 1;

                                return (
                                    <tr key={item.id}>
                                        <td>{sequentialId}</td>
                                        <td>
                                            <img src={`http://localhost:8081/uploads/${item.image}`} alt="User" width={50} height={50} id="circle" />
                                        </td>
                                        <td>{item.firstName}</td>
                                        <td>{item.lastName}</td>
                                        <td>{item.email}</td>
                                        <td>{item.phoneNumber}</td>
                                        <td>
                                            <div id="icons">
                                                <Link to={`/edituser/${item.id}`}>
                                                    <span>
                                                        <i className="fa-solid fa-pen-to-square"></i>
                                                    </span>
                                                </Link>
                                                <span>
                                                    <i className="fa-solid fa-trash" onClick={() => deleteUser(item.id)}></i>
                                                </span>
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}

                        </tbody>
                    </table>
                    <div id='pagination'>
                        <button id='previous' disabled={currentPage === 1} onClick={() => setCurrentPage(currentPage - 1)}>
                            Previous
                        </button>
                        <span>{currentPage} of {totalPages}</span>
                        <button id='next' disabled={currentPage === totalPages
                        } onClick={() => setCurrentPage(currentPage + 1)}>
                            Next
                        </button>
                    </div>
                </main>
            </div>
            <ToastContainer position="top-right" />
        </>
    );
};

export default Users;
