import '../orders.css'


const Orders = () => {

    return (
        <>

            <div className="w3-bar w3-white w3-border-bottom w3-xlarge" >
                <a href="#" className="w3-bar-item w3-button w3-text-red w3-hover-red">
                    <b>
                        <i className="fa fa-map-marker w3-margin-right" /> Logo
                    </b>
                </a>
                <div id='userMenu'>
                    <a href="">Register</a>

                </div>

                <a href="#" className="w3-bar-item w3-button w3-right w3-hover-red w3-text-grey">
                    <i class="fa-solid fa-user"></i> <a href="#" onClick=""><i class="fa-solid fa-cart-shopping" id='cart'><span class="w3-badge"></span></i></a><i class="fa-solid fa-truck-fast"></i>
                </a>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-10 hh-grayBox pt45 pb20">
                        <div class="row justify-content-between">
                            <div class="order-tracking completed">
                                <span class="is-complete"></span>
                                <p>Ordered<br /><span>Mon, June 24</span></p>
                            </div>
                            <div class="order-tracking completed">
                                <span class="is-complete"></span>
                                <p>Shipped<br /><span>Tue, June 25</span></p>
                            </div>
                            <div class="order-tracking">
                                <span class="is-complete"></span>
                                <p>Delivered<br /><span>Fri, June 28</span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>

    )
}

export default Orders;