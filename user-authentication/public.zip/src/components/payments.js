import React, { useState } from 'react';
import axios from 'axios';

const PaymentForm = () => {
    const [userId, setUserId] = useState('');
    const [cardNumber, setCardNumber] = useState('');
    const [expiration, setExpiration] = useState('');
    const [cvv, setCvv] = useState('');

    const handlePayment = async () => {
        try {
            // Make a request to the server to process the payment
            const response = await axios.post('/api/process-payment', {
                userId,
                paymentDetails: {
                    cardNumber,
                    expiration,
                    cvv,
                },
            });

            // Handle the response from the server
            const { success, paymentStatus } = response.data;
            if (success) {
                console.log('Payment processed successfully');
                console.log('Payment Status:', paymentStatus);
                // Perform any necessary actions based on the payment status
            } else {
                console.log('Payment processing failed');
            }
        } catch (error) {
            console.error('Error processing payment:', error);
        }
    };

    return (
        <div>
            <h2>Payment Form</h2>
            <input
                type="text"
                placeholder="User ID"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
            />
            <br />
            <input
                type="text"
                placeholder="Card Number"
                value={cardNumber}
                onChange={(e) => setCardNumber(e.target.value)}
            />
            <br />
            <input
                type="text"
                placeholder="Expiration Date"
                value={expiration}
                onChange={(e) => setExpiration(e.target.value)}
            />
            <br />
            <input
                type="text"
                placeholder="CVV"
                value={cvv}
                onChange={(e) => setCvv(e.target.value)}
            />
            <br />
            <button onClick={handlePayment}>Process Payment</button>
        </div>
    );
};

export default PaymentForm;
