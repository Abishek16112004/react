// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
// import Swal from 'sweetalert2';

// const CartPage = () => {
//     const [cartItems, setCartItems] = useState([]);
//     const [totalPrice, setTotalPrice] = useState(0);

//     useEffect(() => {
//         const storedCartItems = localStorage.getItem('cartItems');
//         if (storedCartItems) {
//             setCartItems(JSON.parse(storedCartItems));
//         }
//     }, []);

//     useEffect(() => {
//         // Calculate the total price
//         const total = cartItems.reduce((accumulator, item) => accumulator + item.productPrice * item.quantity, 0);
//         setTotalPrice(total);
//     }, [cartItems]);

//     const removeCartItem = (index) => {
//         Swal.fire({
//             title: 'Are you sure?',
//             text: 'You want to remove this item',
//             icon: 'warning',
//             showCancelButton: true,
//             confirmButtonColor: '#3085d6',
//             cancelButtonColor: '#d33',
//             confirmButtonText: 'Yes, delete it!'
//         }).then((result) => {
//             if (result.isConfirmed) {
//                 const updatedCartItems = cartItems.filter((_, i) => i !== index);
//                 setCartItems(updatedCartItems);
//                 localStorage.setItem('cartItems', JSON.stringify(updatedCartItems));
//                 Swal.fire('Deleted!', 'Product removed successfully', 'success');
//             }
//         });
//     };

//     const removeAllItems = () => {
//         Swal.fire({
//             title: 'Are you sure?',
//             text: 'You want to remove all items from the cart',
//             icon: 'warning',
//             showCancelButton: true,
//             confirmButtonColor: '#3085d6',
//             cancelButtonColor: '#d33',
//             confirmButtonText: 'Yes, delete all items!'
//         }).then((result) => {
//             if (result.isConfirmed) {
//                 setCartItems([]);
//                 localStorage.removeItem('cartItems');
//                 Swal.fire('Deleted!', 'All items removed successfully', 'success');
//             }
//         });
//     };


//     const navigate = useNavigate();

//     const HomeRedirect = () => {
//         navigate('/homepage');
//     };


//     return (
//         <>
//             {/* Navigation Bar */}
//             <div className="w3-bar w3-white w3-border-bottom w3-xlarge">
//                 <a href="#" onClick={HomeRedirect} className="w3-bar-item w3-button w3-text-red w3-hover-red">
//                     <b>
//                         <i className="fa fa-map-marker w3-margin-right" /> Logo
//                     </b>
//                 </a>
//                 <div id="userMenu">
//                     <a href="">Register</a>
//                 </div>

//                 <a href="#" className="w3-bar-item w3-button w3-right w3-hover-red w3-text-grey">
//                     <a href="/cart">
//                         <i class="fa-solid fa-cart-shopping" id="cart">
//                             <span class="w3-badge">{cartItems.length}</span>
//                         </i>
//                     </a>{' '}
//                     <i className="fa fa-search" />
//                 </a>
//             </div>
//             <div id="cartEqual">
//             <div id="Back">

//             <a href="" id="breadCrumb" onClick={HomeRedirect}>Home / </a> 
//             <a href="#" id='breadCrumb'>Cart</a>
//             </div>
//                 <h1 id="cartItems">Cart Items</h1>
//                 <button id="removeAll" onClick={removeAllItems}>
//                     Remove All Items
//                 </button>
//                 {cartItems.length === 0 ? (
//                     <div id="paddingTable">
//                         <p style={{ textAlign: 'center', fontSize: '20px', fontWeight: '800' }}>Your cart is empty.</p>
//                     </div>
//                 ) : (
//                     <div id="paddingTable">
//                         <table id="customerss">
//                             <thead>
//                                 <tr>
//                                     <th>Image</th>
//                                     <th>Product Name</th>
//                                     <th>Price</th>
//                                     <th>Quantity</th>
//                                     <th>Action</th>
//                                 </tr>
//                             </thead>
//                             <tbody>
//                                 {cartItems.map((item, index) => (
//                                     <tr key={index} id="rowEqalbottom" style={{ paddingBottom: '30px' }}>
//                                         <td>
//                                             <img src={`http://localhost:8081/uploads/${item.image}`} alt={item.productName} width="120" height="100" />
//                                         </td>
//                                         <td className="tdData">{item.productName}</td>
//                                         <td className="tdData">₹{item.productPrice}</td>
//                                         <td>
//                                             <select name="quantity" id="quantity" value={item.quantity} >
//                                                 <option value="1">1</option>
//                                                 <option value="2">2</option>
//                                                 <option value="3">3</option>
//                                                 <option value="4">4</option>
//                                                 <option value="5">5</option>
//                                             </select>
//                                         </td>
//                                         <td>
//                                             <i className="fa-solid fa-trash" onClick={() => removeCartItem(index)}></i>
//                                         </td>
//                                     </tr>
//                                 ))}
//                             </tbody>
//                         </table>

//                         <a href="https://buy.stripe.com/test_00g3dodegbhH5tCbIJ"><button id="checkout">
//                             Proceed to checkout <i class="fa-solid fa-arrow-right"></i>
//                         </button>
//                         </a>
//                     </div>
//                 )}
//             </div>
//         </>
//     );
// };

// export default CartPage;


// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
// import Swal from 'sweetalert2';
// import StripeCheckout from 'react-stripe-checkout'
// import Headers from './headerMain';


// const baseUrl = process.env.REACT_APP_SERVER_URL; // Access the base URL from .env

// const CartPage = () => {
//     const [cartItems, setCartItems] = useState([]);
//     const [totalPrice, setTotalPrice] = useState(0);
//     const [userId, setUserId] = useState('');
//     const [productID, setProductID] = useState('');
//     const [paymentError, setPaymentError] = useState(null);
//     const [paymentSuccess, setPaymentSuccess] = useState(false);

//     useEffect(() => {
//         const storedCartItems = localStorage.getItem('cartItems');
//         if (storedCartItems) {
//             setCartItems(JSON.parse(storedCartItems));
//         }

//         // Fetch the user ID from your authentication system
//         const user = localStorage.getItem('userId');
//         if (user) {
//             setUserId(user);
//         }
//     }, []);

//     useEffect(() => {
//         // Calculate the total price
//         const total = cartItems.reduce((accumulator, item) => accumulator + item.productPrice * item.quantity, 0);
//         setTotalPrice(total);
//     }, [cartItems]);

//     const removeCartItem = (index) => {
//         Swal.fire({
//             title: 'Are you sure?',
//             text: 'You want to remove this item',
//             icon: 'warning',
//             showCancelButton: true,
//             confirmButtonColor: '#3085d6',
//             cancelButtonColor: '#d33',
//             confirmButtonText: 'Yes, delete it!'
//         }).then((result) => {
//             if (result.isConfirmed) {
//                 const updatedCartItems = cartItems.filter((_, i) => i !== index);
//                 setCartItems(updatedCartItems);
//                 localStorage.setItem('cartItems', JSON.stringify(updatedCartItems));
//                 Swal.fire('Deleted!', 'Product removed successfully', 'success');
//             }
//         });
//     };


//     const removeAllItems = () => {
//         Swal.fire({
//             title: 'Are you sure?',
//             text: 'You want to remove all items from the cart',
//             icon: 'warning',
//             showCancelButton: true,
//             confirmButtonColor: '#3085d6',
//             cancelButtonColor: '#d33',
//             confirmButtonText: 'Yes, delete all items!'
//         }).then((result) => {
//             if (result.isConfirmed) {
//                 setCartItems([]);
//                 localStorage.removeItem('cartItems');
//                 Swal.fire('Deleted!', 'All items removed successfully', 'success');
//             }
//         });
//     };

//     const navigate = useNavigate();

//     const HomeRedirect = () => {
//         navigate('/');
//     };
//     const handleSubmit = async (e) => {
//         e.preventDefault();

//         try {
//             // Make a POST request to the /api/orders endpoint
//             const response = await axios.post(`${baseUrl}/api/orders`, {

//                 userId: localStorage.getItem("token"),
//                 cartItems: cartItems
//             });



//             // Handle the response from the server
//             // You can display a success message or redirect to a confirmation page

//             // Clear the cart items from localStorage
//             localStorage.removeItem('cartItems');
//             setCartItems([]);

//             Swal.fire('Success', 'Order placed successfully ! ', 'success');
//         } catch (error) {
//             // Handle the error
//             Swal.fire('Error', 'Failed to place the order', 'error');
//         }
//     };

//     const handleToken = async (token) => {
//         try {
//             const response = await fetch(`${baseUrl}/api/orders`, {
//                 method: 'POST',
//                 headers: {
//                     'Content-Type': 'application/json',
//                 },
//                 body: JSON.stringify({
//                     userId: localStorage.getItem("token"),
//                     cartItems: cartItems,
//                     paymentMethodId: token.id,
//                     paymentStatus: "Done",
//                     email: localStorage.getItem("email")
//                 }),
//             });

//             if (response.ok) {
//                 setPaymentSuccess(true);
//                 localStorage.removeItem('cartItems');
//                 setCartItems([]);
//                 Swal.fire('Success', 'Order placed successfully ! We will notify on your email about tracking progress', 'success');

//             } else {
//                 setPaymentError('Payment failed');
//             }
//         } catch (error) {
//             console.error(error);
//             setPaymentError('Error processing payment');
//         }
//     };

//     const getTotalPrice = () => {
//         // Calculate the total price of all cart items
//         let totalPrice = 0;
//         cartItems.forEach(item => {
//             totalPrice += item.productPrice;
//         });
//         return totalPrice;
//     };

//     const token = localStorage.getItem('token');
//     const isAuthenticated = !!token; // Convert token to boolean value
//     const Register = () => {
//         navigate('/registration');

//     }

//     return (
//         <>
//             {/* Navigation Bar */}
//             <Headers></Headers>
//             <div id="cartEqual">
//                 <div id="Back">
//                     <a href="" id="breadCrumb" onClick={HomeRedirect}>
//                         Home /{' '}
//                     </a>
//                     <a href="#" id="breadCrumb">
//                         Cart
//                     </a>
//                 </div>

//                 {cartItems.length === 0 ? (
//                     <div id="paddingTable">
//                         <img src="https://assets.materialup.com/uploads/66fb8bdf-29db-40a2-996b-60f3192ea7f0/preview.png" style={{ margin: "0 auto", display: "block" }} width="500" alt="" />
//                         <p style={{ textAlign: 'center', fontSize: '20px', fontWeight: '800' }}>Your cart is empty.</p>
//                     </div>
//                 ) : (
//                     <div id="paddingTable">
//                         <button id="removeAll" onClick={removeAllItems}>
//                             <i class="fa-solid fa-circle-exclamation"></i> <span id="removeitem">Remove All Items</span>
//                         </button>
//                         <h1 id="cartItems">Cart Items</h1>
//                         <table id="customerss">
//                             <thead>
//                                 <tr>
//                                     <th>Image</th>
//                                     <th>Product Name</th>
//                                     <th>Price</th>
//                                     <th>Quantity</th>
//                                     <th>Action</th>
//                                 </tr>
//                             </thead>
//                             <tbody>
//                                 {cartItems.map((item, index) => (
//                                     <tr key={index} id="rowEqalbottom" style={{ paddingBottom: '30px' }}>
//                                         <td>
//                                             <img
//                                                 src={`http://localhost:8081/uploads/${item.image}`}
//                                                 alt={item.productName}
//                                                 width="120"
//                                                 height="100"
//                                             />
//                                         </td>
//                                         <td className="tdData">{item.productName}</td>
//                                         <td className="tdData">₹{item.productPrice}</td>
//                                         <td>
//                                             <select required
//                                                 name="quantity"
//                                                 id="quantity"
//                                                 value={item.quantity}
//                                                 onChange={(e) => {
//                                                     const updatedCartItems = [...cartItems];
//                                                     updatedCartItems[index].quantity = e.target.value;
//                                                     setCartItems(updatedCartItems);
//                                                     localStorage.setItem('cartItems', JSON.stringify(updatedCartItems));
//                                                 }}

//                                             >
//                                                 <option value="1" selected="selected">1</option>
//                                                 <option value="2">2</option>
//                                                 <option value="3">3</option>
//                                                 <option value="4">4</option>
//                                                 <option value="5">5</option>
//                                             </select>
//                                         </td>
//                                         <td>
//                                             <i className="fa-solid fa-trash" onClick={() => removeCartItem(index)}></i>
//                                         </td>
//                                     </tr>
//                                 ))}
//                             </tbody>
//                         </table>

//                         {/* <a href="">
//                             <button id="checkout" onClick={handleSubmit} stripeKey="pk_test_51MoQ4iSG2i2tqfEpXOdK5f55pd2Ndjg4tsTVpXDXQGAriwc5qaulqSsxt7KBbOtVUSvMKCznkhxIM2HFd0m8ZQAS00fvsfd3rP"
//                                 token={handleToken}
//                                 amount={totalPrice * 100}>
//                                 Proceed to checkout <i class="fa-solid fa-arrow-right"></i>
//                             </button>
//                         </a> */}
//                         <div>
//                             {isAuthenticated ? (

//                                 <>
//                                     <StripeCheckout
//                                         id="checkout"
//                                         stripeKey="pk_test_51MoQ4iSG2i2tqfEpXOdK5f55pd2Ndjg4tsTVpXDXQGAriwc5qaulqSsxt7KBbOtVUSvMKCznkhxIM2HFd0m8ZQAS00fvsfd3rP"
//                                         token={handleToken}
//                                         amount={totalPrice * 100}
//                                         name="Payment"

//                                     ></StripeCheckout>
//                                     {paymentError && <div>{paymentError}</div>}
//                                 </>


//                             ) : (
//                                 <button id='regisButton'> <a href="#" onClick={Register}>Register <i class="fa-solid fa-arrow-right"></i></a></button>

//                             )}


//                         </div>
//                     </div>
//                 )}
//             </div>
//         </>
//     );
// };

// export default CartPage;

















import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import StripeCheckout from 'react-stripe-checkout'
import Headers from './headerMain';
import FormatPrice from './formatCurrency';
const baseUrl = process.env.REACT_APP_SERVER_URL; // Access the base URL from .env

const CartPage = () => {
    const [cartItems, setCartItems] = useState([]);
    const [totalPrice, setTotalPrice] = useState(0);
    const [userId, setUserId] = useState('');
    const [productID, setProductID] = useState('');
    const [paymentError, setPaymentError] = useState(null);
    const [paymentSuccess, setPaymentSuccess] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        const storedCartItems = localStorage.getItem('cartItems');
        if (storedCartItems) {
            setCartItems(JSON.parse(storedCartItems));
        }

        // Fetch the user ID from your authentication system
        const user = localStorage.getItem('userId');
        if (user) {
            setUserId(user);
        }
    }, []);

    useEffect(() => {
        // Calculate the total price
        const total = cartItems.reduce((accumulator, item) => accumulator + item.productPrice * item.quantity, 0);
        setTotalPrice(total);
    }, [cartItems]);

    const removeCartItem = (index) => {
        Swal.fire({
            title: 'Are you sure?',
            text: 'You want to remove this item',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                let updatedCartItems = cartItems.filter((_, i) => i !== index);
                setCartItems(updatedCartItems);
                localStorage.setItem('cartItems', JSON.stringify(updatedCartItems));
                Swal.fire('Deleted!', 'Product removed successfully', 'success');
            }
        });
    };

    const removeAllItems = () => {
        Swal.fire({
            title: 'Are you sure?',
            text: 'You want to remove all items from the cart',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete all items!'
        }).then((result) => {
            if (result.isConfirmed) {
                setCartItems([]);
                localStorage.removeItem('cartItems');
                Swal.fire('Deleted!', 'All items removed successfully', 'success');
            }
        });
    };

    const navigate = useNavigate();

    const HomeRedirect = () => {
        navigate('/');
    };
    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            // Make a POST request to the /api/orders endpoint
            const response = await axios.post(`${baseUrl}/api/orders`, {
                userId: localStorage.getItem("token"),
                cartItems: cartItems
            });

            // Handle the response from the server
            // You can display a success message or redirect to a confirmation page

            // Clear the cart items from localStorage
            localStorage.removeItem('cartItems');
            setCartItems([]);

            Swal.fire('Success', 'Order placed successfully!', 'success');
        } catch (error) {
            // Handle the error
            Swal.fire('Error', 'Failed to place the order', 'error');
        }
    };

    const handleToken = async (token) => {
        try {
            setIsLoading(true);
            const response = await fetch(`${baseUrl}/api/orders`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    userId: localStorage.getItem("token"),
                    cartItems: cartItems,
                    paymentMethodId: token.id,
                    paymentStatus: "Done",
                    email: localStorage.getItem("email")
                }),
            });

            if (response.ok) {
                setPaymentSuccess(true);
                localStorage.removeItem('cartItems');
                setCartItems([]);
                setTimeout(() => {
                    setIsLoading(false);
                    Swal.fire('Success', 'Order placed successfully! We will notify you via email about the tracking progress', 'success');

                });
            } else {
                setPaymentError('Payment failed');
            }
        } catch (error) {
            console.error(error);
            setPaymentError('Error processing payment');
        }
    };

    const getTotalPrice = () => {
        // Calculate the total price of all cart items
        let totalPrice = 0;
        cartItems.forEach(item => {
            totalPrice += item.productPrice * item.quantity;
        });
        return totalPrice;
    };

    const token = localStorage.getItem('token');
    const isAuthenticated = !!token; // Convert token to boolean value
    const Register = () => {
        navigate('/registration');
    };

    return (
        <>
            {/* Navigation Bar */}
            <Headers></Headers>
            <div id="cartEqual">
                <div id="Back">
                    <a href="" id="breadCrumb" onClick={HomeRedirect}>
                        Home /{' '}
                    </a>
                    <a href="#" id="breadCrumb">
                        Cart
                    </a>
                </div>

                {cartItems.length === 0 ? (
                    <div id="paddingTable">
                        <img src="https://assets.materialup.com/uploads/66fb8bdf-29db-40a2-996b-60f3192ea7f0/preview.png" style={{ margin: "0 auto", display: "block" }} width="500" alt="" />
                        <p style={{ textAlign: 'center', fontSize: '20px', fontWeight: '800' }}>Your cart is empty.</p>
                    </div>
                ) : (
                    <div id="paddingTable">
                        <button id="removeAll" onClick={removeAllItems}>
                            <i className="fa-solid fa-circle-exclamation"></i> <span id="removeitem">Remove All Items</span>
                        </button>
                        <h1 id="cartItems">Cart Items</h1>
                        <table id="customerss">
                     
                            <thead>
                       
                                <tr>
                                    <th>Image</th>
                                    <th>Product Name</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            {isLoading ? (
                    <div className="loading-container">
                        <img
                            src="https://cdn.dribbble.com/users/447957/screenshots/6899626/payment-animation.gif"
                           width={390}  alt="Sending Email" style={{margin:'0 auto',display:'block'}}
                        />
                    </div>
                ) : (
                            <tbody>
                                {cartItems.map((item, index) => (
                                    <tr key={index} id="rowEqalbottom" style={{ paddingBottom: '30px' }}>
                                        <td>
                                            <img
                                                src={`http://localhost:8081/uploads/${item.image}`}
                                                alt={item.productName}
                                                width="120"
                                                height="100"
                                            />
                                        </td>
                                        <td className="tdData">{item.productName}</td>
                                        <td className="tdData">₹{item.productPrice}</td>
                                        <td>
                                            <select
                                                required
                                                name="quantity"
                                                id="quantity"
                                                value={item.quantity || ''}
                                                onChange={(e) => {
                                                    const updatedCartItems = [...cartItems];
                                                    updatedCartItems[index].quantity = parseInt(e.target.value, 10);
                                                    setCartItems(updatedCartItems);
                                                    localStorage.setItem('cartItems', JSON.stringify(updatedCartItems));
                                                }}
                                            >
                                                <option value="" disabled>Select Quantity</option>
                                                {[1, 2, 3, 4, 5].map(quantity => (
                                                    <option key={quantity} value={quantity}>
                                                        {quantity}
                                                    </option>
                                                ))}
                                            </select>
                                        </td>




                                        <td>
                                            <i className="fa-solid fa-trash" onClick={() => removeCartItem(index)}></i>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                )};
                        </table>
                        <h2 style={{ textAlign: 'center' }}>
                            {cartItems.some(item => item.quantity >= 0) && <>Total Price : <FormatPrice price={getTotalPrice() * 100} /></>}
                        </h2>

               
                        <div>
                            {isAuthenticated ? (
                                <>
                                    {cartItems.some(item => item.quantity >= 0) &&
                                        <StripeCheckout
                                            id="checkout"
                                            stripeKey="pk_test_51MoQ4iSG2i2tqfEpXOdK5f55pd2Ndjg4tsTVpXDXQGAriwc5qaulqSsxt7KBbOtVUSvMKCznkhxIM2HFd0m8ZQAS00fvsfd3rP"
                                            token={handleToken}
                                            amount={getTotalPrice() * 100}
                                            name="Payment"
                                        ></StripeCheckout>
                                    }
                                    {paymentError && <div>{paymentError}</div>}

                                </>
                            ) : (
                                <button id="regisButton">
                                    {' '}
                                    <a href="#" onClick={Register}>
                                        Register <i className="fa-solid fa-arrow-right"></i>
                                    </a>
                                </button>
                            )}
                        </div>

                    </div>
                )}
            </div>
        </>
    );
};

export default CartPage;
