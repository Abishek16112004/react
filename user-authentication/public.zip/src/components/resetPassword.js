





import { Form, Button } from 'semantic-ui-react';



import React, { useState } from 'react';
import axios from 'axios';

const ResetPassword = () => {
    const [otp, setOTP] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await axios.post('http://localhost:8081/api/reset-password', { otp, password });
            setMessage(response.data.message);
        } catch (error) {
            setMessage('Failed to reset password');
            console.log(error);
        }
    };

    return (
        <>
            <style>
            .container.mt-0 {"{"}
                background: aliceblue !important; padding-bottom: 234px;
                {"}"}
                input {"{"}
                width: 350px !important;
                {"}"}
            </style>
            <div className='container' id='login'>
                <Form onSubmit={handleSubmit}>
                    <h1 className="text-center">Reset Password</h1>
                    <Form.Field>
                        <label>Email</label>
                        <input
                            type="text"

                            placeholder="Enter OTP"
                            value={otp}
                            onChange={(e) => setOTP(e.target.value)} required
                        />
                    </Form.Field>
                    <Form.Field>
                        <label>Email</label>
                        <input
                            type="text"
                            placeholder="Enter Password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)} required
                        />
                    </Form.Field>
                    <Button type="submit">Submit</Button>
                </Form>
                <p>{message}</p>
            </div>
        </>
    );
};

export default ResetPassword;
