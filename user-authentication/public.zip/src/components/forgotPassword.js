import { useState } from 'react';
import { Form, Button } from 'semantic-ui-react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Swal from 'sweetalert2';

const ForgotPassword = () => {
    const [email, setEmail] = useState('');
    const [message, setMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            setIsLoading(true);
            const response = await axios.post('http://localhost:8081/api/forgot-password', { email });

            // Display the loading image for 3 seconds
            setTimeout(() => {
                setIsLoading(false);
                toast.success(response.data.message);
                setMessage(response.data.message);
            }, 3000);
        } catch (error) {
            setIsLoading(false);
            toast.error('Failed to send password reset email');
            setMessage('Failed to send password reset email');
            console.log(error);
        }
    };
    return (
        <>
            <style>
                {`
                .container.mt-0 {
                    padding-bottom: 199px;
                    background-image: url(https://cdn.dribbble.com/users/87229/screenshots/2190376/sendmail.gif);
                    background-size: cover;
                    background-position: center;
                }
                .loading-container{
                    background-image: url(https://cdn.dribbble.com/users/87229/screenshots/2190376/sendmail.gif);
                    background-size: cover;
                    background-position: center;                }

                input {
                    width: 336px !important;
                }
                img{
                    width:100% !important;
                }
                .container.mt-0 {
    background: aliceblue !important;
    padding-bottom: 388px !important;
}
                `}
            </style>
            <div className={`container mt-0`} id="login">
                {isLoading ? (
                    <div className="loading-container">
                        <img
                            src="https://cdn.dribbble.com/users/87229/screenshots/2190376/sendmail.gif"
                            alt="Sending Email"
                        />
                    </div>
                ) : (
                    <Form onSubmit={handleSubmit}>
                        <h1 className="text-center">Forgot Password</h1>
                        <Form.Field>
                            <label>Email</label>
                            <input
                                type="text"
                                name="email"
                                id="email"
                                placeholder="Email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)} required
                            />
                        </Form.Field>
                        <Button type="submit">Submit</Button>
                    </Form>
                )}
                <ToastContainer position="top-right" />
            </div>
        </>
    );
};

export default ForgotPassword;
