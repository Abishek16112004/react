import axios from 'axios'
import React, { useEffect } from 'react'
import '../sidebar.css'
import Sidebar from './sidebar'
import { useState } from 'react'
import { Button, Checkbox, Form } from 'semantic-ui-react'
import Validate from '../validations/registrationValidation';
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../utils/registrationAxios';
import '../form.css';
import Swal from 'sweetalert2';
const baseUrl = process.env.REACT_APP_SERVER_URL; // Access the base URL from .env


const initialState = {
    firstName: "",
    lastName: "",
    email: "",
    phoneNumber: ""
}
const EditUser = () => {
    const [state, setState] = useState(initialState);
    const { firstName, lastName, email, phoneNumber } = state;
    const navigate = useNavigate();
    const { id } = useParams();
    useEffect(() => {
        axios.get(`${baseUrl}/api/get/${id}`)
            .then((resp) => setState({ ...resp.data[0] }));
    }, [id]);
    const handleSubmit = (e) => {
        e.preventDefault();
        axios.put(`${baseUrl}/api/put/${id}`, {
            firstName,
            lastName,
            email,
            phoneNumber,
        })
            .then(() => {
                setState({ firstName: "", lastName: "", email: "", phoneNumber: "" });
            })

        Swal.fire(
            'Good job!',
            'User has been saved !',
            'success'
        )
        navigate('/users');

    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        setState({ ...state, [name]: value });
    };

    return (
        <>

            <Sidebar></Sidebar>

            <main className="main">
                <div className='container' id='containwidth'>

                    <Form onSubmit={handleSubmit}>
                        <h1 className='text-center'>Edit User</h1>
                        <Form.Field>
                            <label>First Name</label>
                            <input type="text" name="firstName" id="first-name" placeholder='First Name' value={firstName || ""} onChange={handleChange} />
                            {/* <p className='error'>{formErrors.firstName}</p> */}
                        </Form.Field>
                        <Form.Field>
                            <label>Last Name</label>
                            <input type="text" name="lastName" id="last-name" placeholder='Last Name' value={lastName || ""} onChange={handleChange} />
                            {/* <p className='error'>{formErrors.lastName}</p> */}
                        </Form.Field>
                        <Form.Field>
                            <label>Email</label>
                            <input type="text" name="email" id="email" placeholder='Email' value={email || ""} onChange={handleChange} disabled />
                            {/* <p className='error'>{formErrors.email}</p> */}
                        </Form.Field>
                        <Form.Field>
                            <label>Phone Number</label>
                            <input type="text" name="phoneNumber" id="phone-number" placeholder='Phone Number' value={phoneNumber || ""} onChange={handleChange} />
                            {/* <p className='error'>{formErrors.phoneNumber}</p> */}
                        </Form.Field>

                        <Button type='submit'>Submit</Button>
                    </Form>
                    <ToastContainer position="top-right" />
                </div>
            </main>
        </>

    )
}


export default EditUser;