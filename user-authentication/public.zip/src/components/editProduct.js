import axios from 'axios'
import React, { useEffect } from 'react'
import '../sidebar.css'
import Sidebar from './sidebar'
import { useState } from 'react'
import { Button, Checkbox, Form } from 'semantic-ui-react'
import Validate from '../validations/registrationValidation';
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../utils/registrationAxios';
import '../form.css';
import Swal from 'sweetalert2';

const baseUrl = process.env.REACT_APP_SERVER_URL; // Access the base URL from .env

const initialState = {
    productName: "",
    productDescription: "",
    categoryId: '',
    productPrice: "",
    productStock: "",
    image: null,
}
const EditProduct = () => {
    const [state, setState] = useState(initialState);
    const { productName, productDescription, categoryId, productPrice, productStock, image } = state;
    const navigate = useNavigate();
    const { id } = useParams();
    useEffect(() => {
        axios.get(`${baseUrl}/product/get/${id}`)
            .then((resp) => setState({ ...resp.data[0] }));
    }, [id]);

    const [categories, setCategories] = useState([]);


    useEffect(() => {
        // Fetch categories from the server and update the state
        const fetchCategories = async () => {
            try {
                const response = await axios.get(`${baseUrl}/categories`);
                setCategories(response.data);
            } catch (error) {
                console.log(error);
            }
        };


        fetchCategories();
    }, []);
    const handleSubmit = (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('productName', productName);
        formData.append('productDescription', productDescription);
        formData.append('categoryId', categoryId);
        formData.append('productPrice', productPrice);
        formData.append('productStock', productStock);
        formData.append('image', image);

        axios.put(`${baseUrl}/product/put/${id}`, formData)
            .then(() => {
                setState({ productName: "", productDescription: "", categoryId: "", productPrice: "", productStock: "", image: "" });
                Swal.fire(
                    'Good job!',
                    'Product has been updated!',
                    'success'
                );
                navigate('/products');
            })
            .catch((error) => {
                console.log(error);
                Swal.fire(
                    'Error',
                    'Failed to update the product',
                    'error'
                );
            });
    };
    const handleFileChange = (e) => {
        setState({ ...state, image: e.target.files[0] });
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setState({ ...state, [name]: value });
    };

    return (
        <>

            <Sidebar></Sidebar>

            <main className="main">
                <div className='container' id='containwidth'>
                    <img src={image} alt="Product" />

                    <Form onSubmit={handleSubmit} enctype="multipart/form-data">
                        <h1 className='text-center'>Add Product</h1>
                        <Form.Field required>
                            <label>Product Name</label>
                            <input type="text" name="productName" id="product-name" placeholder='Product Name' value={productName || ""} onChange={handleChange} />
                            {/* <p className='error'>{formErrors.productName}</p> */}
                        </Form.Field>
                        <Form.Field required>
                            <label>Product Description</label>
                            <input type="text" name="productDescription" id="product-description" placeholder='Product Description' value={productDescription || ""} onChange={handleChange} />
                            {/* <p className='error'>{formErrors.productDescription}</p> */}
                        </Form.Field>
                        <Form.Field required>
                            <label>Product Category</label>
                            <select
                                name="categoryId"
                                value={categoryId || ""}
                                onChange={handleChange}
                            >
                                <option value="">Select Category</option>
                                {categories.map((category) => (
                                    <option key={category.id} value={category.id}>
                                        {category.categoryName}
                                    </option>
                                ))}
                            </select>
                            {/* <p className="error">{formErrors.categoryId}</p> */}
                        </Form.Field>
                        <Form.Field required>
                            <label>Product Price</label>
                            <input type="text" name="productPrice" id="product-price" placeholder='Price ₹' value={productPrice || ""} onChange={handleChange} />
                            {/* <p className='error'>{formErrors.productPrice}</p> */}
                        </Form.Field>
                        <Form.Field required>
                            <label>Product Stock Quantity</label>
                            <input type="number" name="productStock" id="product-stock" placeholder='Stock' value={productStock || ""} onChange={handleChange} />
                            {/* <p className='error'>{formErrors.productStock}</p> */}
                        </Form.Field>
                        <Form.Field>
                            <label>Product Image Upload</label>
                            <img src='{image || ""}' alt="" />
                            <input type="file" name="image" onChange={handleFileChange} /><br />
                            {/* <p className='error'>{formErrors.image}</p> */}

                        </Form.Field>


                        <Button type='submit'>Submit</Button>
                    </Form>
                    <ToastContainer position="top-right" />
                </div>
            </main>
        </>

    )
}

export default EditProduct;