import axios from 'axios'
import React, { useEffect } from 'react'
import '../sidebar.css'
import Sidebar from './sidebar'
import { useState, useCallback } from 'react'
import { Item } from 'semantic-ui-react'
import { Link } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import Swal from 'sweetalert2'

const baseUrl = process.env.REACT_APP_SERVER_URL; // Access the base URL from .env


const Admin = () => {

    const [data, setData] = useState([]);

    const loadData = useCallback(async () => {
        const response = await axios.get(`${baseUrl}/api/admin/get`);
        setData(response.data);

    }, []);
    useEffect(() => {
        loadData();
        // Update data every second
        const interval = setInterval(loadData, 5000);


        return () => {
            clearInterval(interval);
        };
    }, [loadData]);

    console.log(data);

    const deleteUser = (id) => {

        Swal.fire({
            title: 'Are you sure?',
            text: "You want to delete this user",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                axios.put(`${baseUrl}/api/delete/${id}`);
                Swal.fire(
                    'Deleted!',
                    'User has been deleted ! Please refresh your page',
                    'success'
                )
            }
        })

    }

    return (
        <>

            <Sidebar></Sidebar>
            <div>

                <main className="main">

                    <table id="customers">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Image</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Phone Number</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                data.map((item, index) => {
                                    return (
                                        <tr key={item.id}>
                                            <td>{index + 1}</td>
                                            <td><img src={`${baseUrl}/uploads/${item.image}`} alt="User" width={50} id="circle" /></td>
                                            <td>{item.firstName}</td>
                                            <td>{item.lastName}</td>
                                            <td>{item.email}</td>
                                            <td>{item.phoneNumber}</td>
                                            <td>
                                                <Link to={`/edituser/${item.id}`}>
                                                    <span>
                                                        <i class="fa-solid fa-pen-to-square"></i>
                                                    </span>
                                                </Link>

                                                {/* c */}
                                            </td>

                                        </tr>
                                    )
                                })
                            }

                        </tbody>

                    </table>
                </main>
            </div>
            <ToastContainer position="top-right" />

        </>

    )
}


export default Admin;