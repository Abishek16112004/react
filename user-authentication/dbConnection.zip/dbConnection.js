const express = require("express");
const jwt = require('jsonwebtoken');
const multer = require('multer');
const mysql = require('mysql');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());
const nodemailer = require('nodemailer');
const crypto = require('crypto');



// Db Connection 
const db = mysql.createConnection({
    host: "localhost",
    user: 'root',
    password: 'password',
    database: 'UserAuthentication'
});


// Get all the data form the table where status =0
app.get("/api/get", (req, res) => {
    const sqlGet = "SELECT * FROM users WHERE status = '0'";
    db.query(sqlGet, (error, result) => {
        res.send(result);
    });
});

// Get Admin details from the table
app.get("/api/admin/get", (req, res) => {
    const sqlGet = "SELECT * FROM users WHERE status = '1'";
    db.query(sqlGet, (error, result) => {
        res.send(result);
    });
});


// Get the data with the id so we can get the data pre filled value in form
app.get("/api/get/:id", (req, res) => {
    const { id } = req.params;
    const sqlGet = "SELECT * FROM users WHERE id = ?";
    db.query(sqlGet, id, (error, result) => {
        if (error) {
            console.log(error);
        }
        res.send(result);
    });
});


// Soft delete the user from table
app.put("/api/delete/:id", (req, res) => {
    const { id } = req.params;
    const sqlUpdate = "UPDATE users SET status = '2' WHERE id = ?";
    db.query(sqlUpdate, id, (error, result) => {
        if (error) {
            console.log(error);
        }
        res.send(result);
    });
});


// Update the user value 
app.put("/api/put/:id", (req, res) => {
    const { id } = req.params;
    const { firstName, lastName, email, phoneNumber } = req.body;
    const sqlGet = "UPDATE users SET firstName = ?, lastName = ?, email = ?, phoneNumber = ? WHERE id = ?";
    db.query(sqlGet, [firstName, lastName, email, phoneNumber, id], (error, result) => {
        if (error) {
            console.log(error);
        }
        res.send(result);
    });
});


// Image upload folder path with image name change the random numbers
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './uploads');
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + '.' + file.originalname.split('.').pop());
    }
});


// When we have to call the folder path of image upload then we pass this url
app.use('/uploads', express.static('/var/www/html/user-authentication/server/uploads'));


// Here is insert data form registration form with multer image
const upload = multer({ storage: storage });

app.post('/registration', upload.single('image'), (req, res) => {
    const formData = req.body;
    const errors = {};
    const email_pattern = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/g;
    const phone_pattern = /^[6-9]{1}[0-9]{9}$/;

    const checkEmailQuery = 'SELECT * FROM users WHERE email = ?';
    db.query(checkEmailQuery, formData.email, (err, result) => {
        if (err) {
            console.log(err);
            return res.status(500).json({ error: 'Error in database' });
        }

        if (formData.firstName.trim() === '') {
            errors.firstName = 'First name is required';
        }
        if (formData.lastName.trim() === '') {
            errors.lastName = 'Last name is required';
        }
        if (formData.email.trim() === '') {
            errors.email = 'Email is required';
        } else if (!email_pattern.test(formData.email.trim())) {
            errors.email = 'Email format is invalid';
        }
        else if (result.length > 0) {
            errors.email = 'Email already exists';
        }
        if (formData.phoneNumber.trim() === '') {
            errors.phoneNumber = 'Phone number is required';
        } else if (!phone_pattern.test(formData.phoneNumber.trim())) {
            errors.phoneNumber = 'Phone number is invalid';
        }
        if (formData.password == '') {
            errors.password = 'Password is required';
        }
        if (formData.confirmPassword == '') {
            errors.confirmPassword = 'Confirm Password is required';
        } else if (formData.password !== formData.confirmPassword) {
            errors.confirmPassword = 'Password does not match';
        }

        if (formData.dob.trim() === '') {
            errors.dob = 'Date of birth is required';
        }
        if (formData.department == '') {
            errors.department = 'Department is required';
        }
        if (!req.file || !req.file.mimetype.startsWith('image/')) {
            errors.image = 'Image is required and must be of image format(JPEG/PNG/JPEG)';
        }
        if (formData.gender == '') {
            errors.gender = 'Gender is required';
        }

        if (Object.keys(errors).length > 0) {
            return res.status(400).json({ errors: errors });
        }

        const insertQuery = 'INSERT INTO users (`firstName`, `lastName`, `email`, `phoneNumber`, `password`, `dob`, `gender`, `department`, `image`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
        const values = [
            formData.firstName,
            formData.lastName,
            formData.email,
            formData.phoneNumber,
            formData.password,
            formData.dob,
            formData.gender,
            formData.department,
            req.file.filename
        ];

        db.query(insertQuery, values, (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ error: 'Error in database' });
            }
            return res.json(result);
        });
    });
});

// Use the jwt token for the login check
const verifyJwt = (req, res, next) => {
    const token = req.headers["access-token"];
    if (!token) {
        return res.json("Token not provided");
    } else {
        jwt.verify(token, "jwtSecretKey", (err, decoded) => {
            if (err) {
                res.json("Not Authenticated");
            } else {
                req.userId = decoded.id;
                next();
            }
        });
    }
};

// This code will verify the jwt token
app.get('/checkauth', verifyJwt, (req, res) => {
    return res.json("Authenticated");
});


// Here this code checks the login credentials with the permission of user and admin based on the status
app.post('/login', (req, res) => {
    const sql = "SELECT id, firstName, email, phoneNumber, password, status, image FROM users WHERE email = ? AND password = ?";

    db.query(sql, [req.body.email, req.body.password], (err, result) => {
        if (err) return res.json({ Message: "Error in node" });
        if (result.length) {
            const id = result[0].id;
            const email = result[0].email;
            const firstName = result[0].firstName;
            const phoneNumber = result[0].phoneNumber;
            const image = result[0].image;
            const token = jwt.sign({ id }, "jwtSecretKey", { expiresIn: 300 });

            if (result[0].status === "1") {
                // Admin login
                return res.json({ Login: true, role: 'admin', id, token: id });
            } else {
                // User login
                return res.json({ Login: true, role: 'user', id, token: id, email: email, firstName: firstName, phoneNumber: phoneNumber, image: image });
            }
        } else {
            return res.json({ Login: false });
        }
    });
});

//**************************End of registration and login form check **********************  


// --------------------------------------------------------------------------------------------------------------------------


// ************************* Product Add, update , delete action code **********************


// Here is insert product data form with multer image
app.post('/product', upload.single('image'), (req, res) => {
    const formData = req.body;
    const errors = {};


    if (formData.productName.trim() === '') {
        errors.productName = 'Product name  is required';
    }
    if (formData.productDescription.trim() === '') {
        errors.productDescription = 'Product Description is required';
    }
    if (formData.productPrice.trim() === '') {
        errors.productPrice = 'Product Price is required';
    }
    if (formData.productStock == '') {
        errors.productStock = 'Product Stock is required';
    }
    if (!req.file || !req.file.mimetype.startsWith('image/')) {
        errors.image = 'Image is required and must be of image format(JPEG/PNG/JPEG)';
    }
    if (Object.keys(errors).length > 0) {
        return res.status(400).json({ errors: errors });
    }

    const insertQuery = 'INSERT INTO products (`productName`, `productDescription`, `category` , `productPrice`, `productStock`, `image`) VALUES (?, ?, ?, ?, ?, ?)';
    const values = [
        formData.productName,
        formData.productDescription,
        formData.categoryId,
        formData.productPrice,
        formData.productStock,
        req.file.filename
    ];

    db.query(insertQuery, values, (err, result) => {
        if (err) {
            console.log(err);
            return res.status(500).json({ error: 'Error in database' });
        }
        return res.json(result);
    });
});


// Get all the data form the table where status =0
app.get("/product/get", (req, res) => {
    const sqlGet = "SELECT * FROM products INNER JOIN category ON  products.category = category.id ";
    db.query(sqlGet, (error, result) => {
        res.send(result);
    });
});


// Soft delete the product from table
app.put("/product/delete/:id", (req, res) => {
    const { id } = req.params;
    const sqlUpdate = "UPDATE products SET status = '2' WHERE id = ?";
    db.query(sqlUpdate, id, (error, result) => {
        if (error) {
            console.log(error);
        }
        res.send(result);
    });
});


// Get the data with the id so we can get the data pre filled value in form
app.get("/product/get/:id", (req, res) => {
    const { id } = req.params;
    const sqlGet = "SELECT * FROM products WHERE id = ?";
    db.query(sqlGet, id, (error, result) => {
        if (error) {
            console.log(error);
        }
        res.send(result);
    });
});


// // Update the user value 
// app.put("/product/put/:id", upload.single('image'), (req, res) => {
//     const { id } = req.params;
//     const { productName, productDescription, productPrice, productStock, image } = req.body;
//     const sqlGet = "UPDATE products SET productName = ?, productDescription = ?, productPrice = ?, productStock = ?, image = ? WHERE id = ?";
//     db.query(sqlGet, [productName, productDescription, productPrice, productStock, image,  id], (error, result) => {
//         if (error) {
//             console.log(error);
//         }
//         res.send(result);
//     });
// });

//Update the product  
app.put('/product/put/:id', upload.single('image'), (req, res) => {
    const { id } = req.params;
    const { productName, productDescription, categoryId, productPrice, productStock } = req.body;
    const image = req.file; // Access the uploaded file using req.file

    const sqlUpdate = 'UPDATE products SET productName = ?, productDescription = ?, category = ?,  productPrice = ?, productStock = ?, image = ? WHERE id = ?';
    const params = [productName, productDescription, categoryId, productPrice, productStock, image.filename, id]; // Assuming you want to store the filename in the database

    db.query(sqlUpdate, params, (error, result) => {
        if (error) {
            console.log(error);
            return res.status(500).send('Failed to update the product.');
        }
        res.send(result);
    });
});



// Activate product
app.put('/product/activate/:id', (req, res) => {
    const { id } = req.params;
    const sqlUpdate = 'UPDATE products SET status = "0" WHERE id = ?';

    db.query(sqlUpdate, id, (error, result) => {
        if (error) {
            console.log(error);
            return res.status(500).send('Failed to activate the product.');
        }
        res.send(result);
    });
});

// Deactivate product
app.put('/product/deactivate/:id', (req, res) => {
    const { id } = req.params;
    const sqlUpdate = 'UPDATE products SET status = "1" WHERE id = ?';

    db.query(sqlUpdate, id, (error, result) => {
        if (error) {
            console.log(error);
            return res.status(500).send('Failed to deactivate the product.');
        }
        res.send(result);
    });
});


// Get all the data form the table where status =0
app.get("/products/get", (req, res) => {
    const sqlGet = "SELECT * FROM products WHERE status = '0' ";
    db.query(sqlGet, (error, result) => {
        res.send(result);
    });
});




// app.post('/api/orders', (req, res) => {
//     const { userId, cartItems } = req.body;

//     // Retrieve the user ID from local storage
//     const insertQuery = 'INSERT INTO orders (user_id, product_id) VALUES (?, ?)';
//     const values = [userId, cartItems[0].id];

//     db.query(insertQuery, values, (err, result) => {
//         if (err) {
//             console.error(err);
//             return res.status(500).json({ error: 'Error in database' });
//         }
//         return res.json(result);
//     });
// });


// app.post('/api/orders', (req, res) => {
//     const { userId, cartItems } = req.body;

//     // Retrieve the user ID from local storage
//     const insertQuery = 'INSERT INTO orders (user_id, product_id,productPrice) VALUES ?';
//     const values = [];

//     // Build the values array by iterating over cartItems and extracting product IDs
//     cartItems.forEach(item => {
//         values.push([userId, item.id, item.productPrice]);
//     });

//     db.query(insertQuery, [values], (err, result) => {
//         if (err) {
//             console.error(err);
//             return res.status(500).json({ error: 'Error in database' });
//         }
//         return res.json(result);
//     });
// });


// app.post('/api/orders', async (req, res) => {
//     const { userId, cartItems, paymentMethodId } = req.body;

//     // Build the values array by iterating over cartItems and extracting product IDs
//     const values = [];
//     cartItems.forEach(item => {
//         values.push([userId, item.id, item.productPrice]);
//     });

//     try {
//         // Create a payment intent with Stripe
//         const paymentIntent = await stripe.paymentIntents.create({
//             amount: calculateTotalPrice(cartItems) * 100, // Convert the total amount to cents
//             currency: 'usd',
//             payment_method: paymentMethodId,
//             confirm: true
//         });

//         // Check if the payment was successful
//         if (paymentIntent.status !== 'succeeded') {
//             return res.status(400).json({ error: 'Payment failed' });
//         }

//         // Retrieve the user ID from local storage
//         const insertQuery = 'INSERT INTO orders (user_id, product_id, productPrice, paymentStatus) VALUES ?';
//         const updatedValues = values.map(value => [...value, 'Paid']);

//         // Insert the order into the database with payment status as 'Paid'
//         db.query(insertQuery, [updatedValues], (err, result) => {
//             if (err) {
//                 console.error(err);
//                 return res.status(500).json({ error: 'Error in database' });
//             }
//             return res.json(result);
//         });
//     } catch (error) {
//         console.error(error);
//         return res.status(500).json({ error: 'Error processing payment' });
//     }
// });




const stripe = require('stripe')('sk_test_51MoQ4iSG2i2tqfEpxSvIINz0AC8CUvQJG36HWxejvf9FSPDWiplpbNqQWhWlB5IAjWA7e6PMwlQnlouTSJJVUInn00x6GGpang');

// app.post('/api/orders', async (req, res) => {
//     const { userId, cartItems, paymentMethodId } = req.body;

//     try {
//         // Calculate the total amount of the order
//         const totalPrice = 50;

//         // Create a payment intent with Stripe
//         const paymentIntent = await stripe.paymentIntents.create({
//             amount: totalPrice * 100, // Convert the total amount to cents
//             currency: 'usd',
//             payment_method_data: {
//                 type: 'card',
//                 card: {
//                     token: paymentMethodId
//                 }
//             },
//             confirm: true
//         });


//         // Prepare the order data for database insertion
//         const orderValues = cartItems.map(item => [userId, item.id, item.productPrice,'done',item.quantity]);

//         // Insert the order into the database with payment status as 'Paid'
//         db.query('INSERT INTO orders (user_id, product_id, productPrice, paymentStatus, quantity) VALUES ?', [orderValues], (err, result) => {
//             if (err) {
//                 console.error(err);
//                 return res.status(500).json({ error: 'Error in database' });
//             }

//             return res.json(result);
//         });
//     } catch (error) {
//         console.error(error);

//         return res.status(500).json({ error: 'Error processing payment' });
//     }
// });


app.post('/api/orders', async (req, res) => {
    const { userId, cartItems, paymentMethodId, email } = req.body;

    try {
        // Calculate the total amount of the order
        const totalPrice = cartItems.reduce((total, item) => total + (item.productPrice * item.quantity), 0);

        // Create a payment intent with Stripe
        const paymentIntent = await stripe.paymentIntents.create({
            amount: totalPrice * 100,
            currency: 'usd',
            payment_method_data: {
                type: 'card',
                card: {
                    token: paymentMethodId,
                },
            },
            confirm: true,
        });



        // Prepare the order data for database insertion
        const orderValues = cartItems.map(item => [
            userId,
            item.id,
            item.productPrice,
            'done',
            item.quantity,
        ]);

        // Insert the order into the database with payment status as 'Paid'
        db.query(
            'INSERT INTO orders (user_id, product_id, productPrice, paymentStatus, quantity) VALUES ?',
            [orderValues],
            async (err, result) => {
                if (err) {
                    console.error(err);
                    return res.status(500).json({ error: 'Error in database' });
                }

                try {

                    // Send an email notification to the user
                    const transporter = nodemailer.createTransport({
                        service: 'Gmail',
                        auth: {
                            user: 'abishekkumar1611@gmail.com',
                            pass: 'nnojkuvgumxpmgrf',
                        },
                    });

                    const mailOptions = {
                        from: 'abishekkumar1611@gmail.com',
                        to: email,
                        subject: 'Order Confirmation',
                        html: `
                          <style>
                            table {
                              font-family: arial, sans-serif;
                              border-collapse: collapse;
                              width: 80%;
                              margin : 0 auto !important;
                            }
                      
                            td, th {
                              border: 1px solid #dddddd;
                              text-align: left;
                              padding: 8px;
                            }
                      
                            tr:nth-child(even) {
                              background-color: #dddddd;
                            }
                            a{
                                color:white !important;
                            }
                          </style>
                          <div style="margin:0 auto; display:block; text-align:center !important;border:2px dashed black; width:50%">
                            <img src="https://img.freepik.com/premium-vector/smartphone-delivery-service-worker-wearing-medical-mask-motorcycle-illustration-design_24908-68077.jpg?w=740" width="400px" style="margin:0 auto; display:block">
                            <h1> Hi ${email}</h1>
                            <h1>Thanks for purchase! Order Successfull</h1>
                            <p>Here is your ordered product list:</p>
                            <table>
                              <tr>
                                <th>S.No</th>
                                <th>Product Name</th>
                                <th>Product Price</th>
                              </tr>
                              ${cartItems.map((item, index) => `
                                <tr>
                                  <td>${index + 1}</td>
                                  <td>${item.productName}</td>
                                  <td>${item.productPrice}</td>
                                </tr>
                              `).join('')}
                            </table>
                            <button style="background-color: #ff5353;
                            color: white;
                            border: none;
                            padding: 16px;
                            margin-top:20px;
                            margin-bottom:20px;
                            border-radius: 20px;
                            width: 158px;
                            font-size: 19px;
                            font-weight: bold;"><a href="http://localhost:3000/homepage">Shop Now</a></button>

                          </div>
                        `,
                    };



                    if (!mailOptions.to) {
                        throw new Error('No email recipient defined');
                    }

                    await transporter.sendMail(mailOptions);
                    console.log('Order confirmation email sent successfully');
                } catch (error) {
                    console.error('Failed to send order confirmation email:', error);
                } finally {
                    emailSending = false; // Set emailSending flag to false
                }

                return res.json(result);
            }
        );
    } catch (error) {
        console.error(error);
        return res.status(500).json({ error: 'Error processing payment' });
    }
});


// Get all the data form the table where status =0
app.get("/orders/get", (req, res) => {
    const sqlGet = "SELECT users.firstName, users.email, users.image, products.productName, orders.productPrice, orders.paymentStatus, orders.quantity, orders.ordered_date FROM orders INNER JOIN users ON orders.user_id = users.id INNER JOIN products ON orders.product_id = products.id";
    db.query(sqlGet, (error, result) => {
        res.send(result);
    });
});


// app.post('/category', (req, res) => {
//     const formData = req.body;
//     const errors = {};

//     if (formData.categoryName == '') {
//         errors.categoryName = 'Category name is required';
//     }
//     if (formData.categoryDescription == '') {
//         errors.categoryDescription = 'Category description is required';
//     }

//     if (Object.keys(errors).length > 0) {
//         return res.status(400).json({ errors: errors });
//     }

//     const insertQuery = 'INSERT INTO category (`categoryName`, `categoryDescription`) VALUES (?, ?)';
//     const values = [
//         formData.categoryName,
//         formData.categoryDescription
//     ];

//     db.query(insertQuery, values, (err, result) => {
//         if (err) {
//             console.log(err);
//             return res.status(500).json({ error: 'Error in database' });
//         }
//         return res.json(result);
//     });
// });

// API route for inserting a category
app.post('/category', (req, res) => {
    const { categoryName, categoryDescription } = req.body;

    // Insert the category into the database
    const query = 'INSERT INTO category (categoryName, categoryDescription) VALUES (?, ?)';
    db.query(query, [categoryName, categoryDescription], (err, results) => {
        if (err) {
            console.error('Error inserting category: ', err);
            res.sendStatus(500);
            return;
        }
        res.sendStatus(201); // Category successfully inserted
    });
});









// Get all the data form the table where status =0
app.get("/category/get", (req, res) => {
    const sqlGet = "SELECT * FROM category where status = '0'";
    db.query(sqlGet, (error, result) => {
        res.send(result);
    });
});


// Soft delete the product from table
app.put("/category/delete/:id", (req, res) => {
    const { id } = req.params;
    const sqlUpdate = "UPDATE category SET status = '2' WHERE id = ?";
    db.query(sqlUpdate, id, (error, result) => {
        if (error) {
            console.log(error);
        }
        res.send(result);
    });
});


// Get the data with the id so we can get the data pre filled value in form
app.get("/category/get/:id", (req, res) => {
    const { id } = req.params;
    const sqlGet = "SELECT * FROM category WHERE id = ?";
    db.query(sqlGet, id, (error, result) => {
        if (error) {
            console.log(error);
        }
        res.send(result);
    });
});


// // Update the user value 
// app.put("/product/put/:id", upload.single('image'), (req, res) => {
//     const { id } = req.params;
//     const { productName, productDescription, productPrice, productStock, image } = req.body;
//     const sqlGet = "UPDATE products SET productName = ?, productDescription = ?, productPrice = ?, productStock = ?, image = ? WHERE id = ?";
//     db.query(sqlGet, [productName, productDescription, productPrice, productStock, image,  id], (error, result) => {
//         if (error) {
//             console.log(error);
//         }
//         res.send(result);
//     });
// });

//Update the product  
app.put('/category/put/:id', (req, res) => {
    const { id } = req.params;
    const { categoryName, categoryDescription } = req.body;

    const sqlUpdate = 'UPDATE category SET categoryName = ?, categoryDescription = ? WHERE id = ?';
    const params = [categoryName, categoryDescription, id]; // Assuming you want to store the filename in the database

    db.query(sqlUpdate, params, (error, result) => {
        if (error) {
            console.log(error);
            return res.status(500).send('Failed to update the product.');
        }
        res.send(result);
    });
});



// Activate product
app.put('/category/activate/:id', (req, res) => {
    const { id } = req.params;
    const sqlUpdate = 'UPDATE category SET status = "0" WHERE id = ?';

    db.query(sqlUpdate, id, (error, result) => {
        if (error) {
            console.log(error);
            return res.status(500).send('Failed to activate the product.');
        }
        res.send(result);
    });
});

// Deactivate product
app.put('/category/deactivate/:id', (req, res) => {
    const { id } = req.params;
    const sqlUpdate = 'UPDATE products SET status = "1" WHERE id = ?';

    db.query(sqlUpdate, id, (error, result) => {
        if (error) {
            console.log(error);
            return res.status(500).send('Failed to deactivate the product.');
        }
        res.send(result);
    });
});


// Get all the data form the table where status =0
app.get("/category/get", (req, res) => {
    const sqlGet = "SELECT * FROM category WHERE status = '0' ";
    db.query(sqlGet, (error, result) => {
        res.send(result);
    });
});
// i have a product table and i have a category id in product table but in listing table in want to show with another table 
// Get all the data form the table where status =0
app.get("/count/category/get", (req, res) => {
    const sqlGet = "SELECT category, COUNT(*) AS productCount FROM products GROUP BY category";
    db.query(sqlGet, (error, result) => {
        res.send(result);
    });
});


// GET endpoint to fetch the category list
app.get('/categories', (req, res) => {
    const sqlSelect = 'SELECT id, categoryName FROM category';

    db.query(sqlSelect, (error, results) => {
        if (error) {
            console.log(error);
            return res.status(500).send('Failed to fetch categories.');
        }
        res.send(results);
    });
});


// Show all the total count in the admin dashboard

app.get('/dashboardData', (req, res) => {
    const totalProductsQuery = 'SELECT COUNT(*) as totalProducts FROM products';
    const totalCategoriesQuery = 'SELECT COUNT(*) as totalCategories FROM category';
    const totalCustomersQuery = 'SELECT COUNT(*) as totalCustomers FROM users WHERE status = "0" ';
    const totalOrdersQuery = 'SELECT COUNT(*) as totalOrders FROM orders';
    const completedOrdersQuery = 'SELECT COUNT(*) as completedOrders FROM orders WHERE status = "0"';
    const pendingOrdersQuery = 'SELECT COUNT(*) as pendingOrders FROM orders WHERE status = "1"';

    let dashboardData = {};

    db.query(totalProductsQuery, (error, results) => {
        if (error) {
            console.error('Error retrieving total products:', error);
            return res.status(500).send('Internal Server Error');
        }

        dashboardData.totalProducts = results[0].totalProducts;

        db.query(totalCategoriesQuery, (error, results) => {
            if (error) {
                console.error('Error retrieving total categories:', error);
                return res.status(500).send('Internal Server Error');
            }

            dashboardData.totalCategories = results[0].totalCategories;

            db.query(totalCustomersQuery, (error, results) => {
                if (error) {
                    console.error('Error retrieving total customers:', error);
                    return res.status(500).send('Internal Server Error');
                }

                dashboardData.totalCustomers = results[0].totalCustomers;

                db.query(totalOrdersQuery, (error, results) => {
                    if (error) {
                        console.error('Error retrieving total orders:', error);
                        return res.status(500).send('Internal Server Error');
                    }

                    dashboardData.totalOrders = results[0].totalOrders;

                    db.query(completedOrdersQuery, (error, results) => {
                        if (error) {
                            console.error('Error retrieving completed orders:', error);
                            return res.status(500).send('Internal Server Error');
                        }

                        dashboardData.completedOrders = results[0].completedOrders;

                        db.query(pendingOrdersQuery, (error, results) => {
                            if (error) {
                                console.error('Error retrieving pending orders:', error);
                                return res.status(500).send('Internal Server Error');
                            }

                            dashboardData.pendingOrders = results[0].pendingOrders;

                            res.json(dashboardData);
                        });
                    });
                });
            });
        });
    });
});



// API endpoint for forgot password
app.post('/api/forgot-password', (req, res) => {
    const { email } = req.body;

    // Generate a unique token
    const token = crypto.randomBytes(20).toString('hex');
    const otp = Math.floor(100000 + Math.random() * 900000);

    // Update the token and expiration time in the database for the user with the given email
    const query = 'UPDATE users SET resetToken = ?, resetTokenExpiresAt = ? WHERE email = ?';
    const expirationTime = new Date(Date.now() + 60000); // 1 minute from now
    db.query(query, [otp, expirationTime, email], (error, results) => {
        if (error) {
            console.log('Error updating token in the database:', error);
            res.status(500).json({ message: 'Internal server error' });
        } else {
            // Send email with the reset password link containing the token
            const resetPasswordLink = `http://localhost:3000/reset-password?token=${token}`;
            const OTP = `Please copy the token code and paste it in the reset input: ${otp}`;

            // Send the email
            sendResetPasswordEmail(email, resetPasswordLink, OTP);

            // Schedule the expiration of the OTP after 1 minute
            setTimeout(() => {
                const expirationQuery = 'UPDATE users SET resetToken = NULL, resetTokenExpiresAt = NULL WHERE email = ?';
                db.query(expirationQuery, [email], (expirationError, expirationResults) => {
                    if (expirationError) {
                        console.log('Error expiring token in the database:', expirationError);
                    }
                });
            }, 60000); // 1 minute

            res.status(200).json({ message: 'Password reset email sent' });
        }
    });
});



// API endpoint for reset password
app.post('/api/reset-password', (req, res) => {
    const { otp, password } = req.body;

    // Update the user's password in the database based on the token
    const query = 'UPDATE users SET password = ?, resetToken="0" WHERE resetToken = ?';
    db.query(query, [password, otp], (error, results) => {
        if (error) {
            console.log('Error updating password in the database:', error);
            res.status(500).json({ message: 'Internal server error' });
        } else if (results.affectedRows === 0) {
            // No matching token found in the database
            res.status(404).json({ message: 'Token not found' });
        } else {
            res.status(200).json({ message: 'Password reset successfully' });
        }
    });
});

// Helper function to send the reset password email
function sendResetPasswordEmail(email, resetPasswordLink, OTP) {
    // Use an email sending library (e.g., Nodemailer) to send the email
    // Send an email notification to the user
    const transporter = nodemailer.createTransport({
        service: 'Gmail',
        auth: {
            user: 'abishekkumar1611@gmail.com',
            pass: 'nnojkuvgumxpmgrf',
        },
    });

    const mailOptions = {
        from: 'abishekkumar1611@gmail.com',
        to: email,
        subject: 'Password Reset',
        html: `
        <!DOCTYPE html>
<html>
<head>
<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
width:900px;
margin: auto;
  text-align: center;
  font-family: arial;
  padding:20px;
}

.price {
  color: grey;
  font-size: 22px;
}

.button {
  border: none;
  outline: 0;
  padding: 10px;
  border-radius:30px;
  color: white;
  background-color: #000;
  text-align: center;
  width: 80%;
  font-size: 18px;
  cursor:auto;
  margin:auto;
}
p#link {
    font-size: 15px;
}
p#token {
    font-size: 20px;
    font-weight: bolder;
}
a{
    color:white;
}

</style>
</head>
<body>

<h2 style="text-align:center">Forgot Password</h2>

<div class="card">
  <img src="https://img.freepik.com/free-vector/forgot-password-concept-illustration_114360-1095.jpg?w=2000" alt="Denim Jeans" style="width:40%">
  <h1>Dear ${email}</h1>
  <p>Seems like you forgot your password. <br>Don't worry, use below token code to reset your passowrd. It is valid for 5 minutes only.</p>
  
  <p><div class="button"> <p id="token">${OTP} <p id="link"><b>Click this url link to forgot you password : </b><br> <a href="${resetPasswordLink}">${resetPasswordLink}</a></p></div></p>
  
  <p>Simply ignore this email if you did not requested for it.</p>
    <h1>Thanks</h1>
   <p>Team Digital</p>

</div>

</body>
</html>

       `,
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log('Error sending email:', error);
        } else {
            console.log('Email sent:', info.response);
        }
    });
}

//******************************End of product code **************************************** 


// Here we have create a server connection url port
app.listen(8081, 'localhost', () => {
    console.log("connected to the server");
})

